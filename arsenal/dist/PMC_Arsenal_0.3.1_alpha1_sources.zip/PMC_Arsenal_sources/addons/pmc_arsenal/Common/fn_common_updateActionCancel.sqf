#include "defineCommon.inc"

params["_object",["_text",""]];

private _id = _object getVariable "pmca_ui_cancelAction_id";

if(isnil "_id")exitWith{};

_object setUserActionText [_id,  format["<t color='#FFA500'>%1 %2",localize "STR_PMCAC_ACT_CANCEL",_text]];

