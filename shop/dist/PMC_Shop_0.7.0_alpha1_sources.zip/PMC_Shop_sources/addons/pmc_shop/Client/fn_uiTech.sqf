// [event, arguments] -> nothing. Client. The gunsmith's page ("Техник") in the market
// laptop's browser: the player's weapons (rifle, launcher, handgun), the vest worn and the
// items the gunsmith takes (weapon parts, warbelts, old uniforms) on the left; the upgrades
// the chosen weapon or vest can take on the right, each with its cost in money and items
// (what the player has against what it needs). "Улучшить" asks for a
// second click, then the server checks and charges (PMCS_fnc_upgrade) and the player's
// machine swaps the weapon (PMCS_fnc_upgradeApply).
params ["_event", ["_args", []]];
if (isNil "PMCS_ui" || {(PMCS_ui getOrDefault ["site", "shop"]) != "tech"}) exitWith {};
private _make = {_this call PMCS_fnc_uiMake};
private _money = {[_this] call PMCS_fnc_money};
private _click = {
    params ["_ctrl", "_event", ["_args", []]];
    _ctrl setVariable ["PMCS_event", [_event, _args]];
    _ctrl ctrlAddEventHandler ["ButtonClick", {(_this select 0) getVariable "PMCS_event" call PMCS_fnc_uiTech}];
    _ctrl
};
private _weaponName = {
    private _shown = getText (configFile >> "CfgWeapons" >> _this >> "displayName");
    [_shown, _this] select (_shown == "")
};
switch (_event) do {
    case "build": {
        ["PMCS_Text", [0.6, 0.079, 0.22, 0.022], controlNull, "page", localize "STR_PMCS_PAY_WITH", 0.016, "navyText"] call _make;
        private _account = ["PMCS_Combo", [0.6, 0.103, 0.22, 0.032], controlNull, "page", "", 0.018] call _make;
        _account ctrlAddEventHandler ["LBSelChanged", {
            params ["_ctrl", "_row"];
            if (_row >= 0 && {(_ctrl lbData _row) != (PMCS_ui get "account")}) then {PMCS_ui set ["account", _ctrl lbData _row]; ["body"] call PMCS_fnc_uiTech};
        }];
        PMCS_ui set ["accountCtrl", _account];
        ["PMCS_Text", [0, 0.145, 0.3, 0.805], controlNull, "page", "", 0.02, "", "panel"] call _make;
        ["PMCS_Text", [0.3, 0.145, 0.7, 0.805], controlNull, "page", "", 0.02, "", "screen"] call _make;
        ["PMCS_Text", [0.299, 0.145, 0.001, 0.805], controlNull, "page", "", 0.02, "", "line"] call _make;
        PMCS_ui set ["techGroup", ["PMCS_Group", [0.3, 0.2, 0.7, 0.75], controlNull, "page"] call _make];
        [["PMCS_Button", [0.835, 0.088, 0.15, 0.045], controlNull, "page", localize "STR_PMCS_TREE_OPEN", 0.019, "text", "orange"] call _make, "tree", [true]] call _click;
        (PMCS_ui get "address") ctrlSetText localize "STR_PMCS_ADDRESS_TECH";
        ["refresh"] call PMCS_fnc_uiTech;
    };
    case "refresh": {
        if !("market" in PMCS_ui) exitWith {};
        (PMCS_ui get "bank") params ["_personal", "_group", "_treasurer"];
        private _account = PMCS_ui get "accountCtrl";
        lbClear _account;
        _account lbSetData [_account lbAdd format [localize "STR_PMCS_ACCOUNT_PERSONAL", _personal call _money], "personal"];
        if (_treasurer) then {_account lbSetData [_account lbAdd format [localize "STR_PMCS_ACCOUNT_GROUP", _group call _money], "group"]};
        if (!_treasurer) then {PMCS_ui set ["account", "personal"]};
        _account lbSetCurSel ([0, 1] select ((PMCS_ui get "account") == "group"));
        ["body"] call PMCS_fnc_uiTech;
    };
    case "body": {
        ["tech"] call PMCS_fnc_uiClear;
        // Four places the gunsmith works on: rifle, launcher, handgun and the vest worn.
        private _carried = [primaryWeapon player, secondaryWeapon player, handgunWeapon player, vest player];
        private _offersOf = {
            params ["_slot", "_class"];
            if (_slot == 3) then {[_class] call PMCS_fnc_gearUpgradesFor} else {[_class] call PMCS_fnc_upgradesFor}
        };
        if ((_carried select (PMCS_ui getOrDefault ["techSlot", 0])) == "") then {
            private _withOffers = -1;
            {if (_withOffers < 0 && {_x != ""} && {([_forEachIndex, _x] call _offersOf) isNotEqualTo []}) then {_withOffers = _forEachIndex}} forEach _carried;
            PMCS_ui set ["techSlot", (_withOffers max (_carried findIf {_x != ""})) max 0];
        };
        private _slot = PMCS_ui getOrDefault ["techSlot", 0];
        ["PMCS_TextBold", [0.015, 0.155, 0.27, 0.026], controlNull, "tech", localize "STR_PMCS_TECH_WEAPONS", 0.016, "grey"] call _make;
        {
            private _class = _x;
            private _y = 0.185 + _forEachIndex * 0.108;
            private _on = _forEachIndex == _slot && {_class != ""};
            if (_on) then {["PMCS_Text", [0.012, _y - 0.004, 0.276, 0.106], controlNull, "tech", "", 0.02, "", "orange"] call _make};
            ["PMCS_Text", [0.015, _y, 0.27, 0.098], controlNull, "tech", "", 0.02, "", "white"] call _make;
            ["PMCS_Text", [0.022, _y + 0.004, 0.25, 0.022], controlNull, "tech",
                localize (["STR_PMCS_SLOT_RIFLE", "STR_PMCS_SLOT_LAUNCHER", "STR_PMCS_SLOT_HANDGUN", "STR_PMCS_SLOT_VEST"] select _forEachIndex), 0.014, "grey"] call _make;
            if (_class == "") then {
                ["PMCS_Text", [0.022, _y + 0.036, 0.25, 0.03], controlNull, "tech", localize "STR_PMCS_SLOT_EMPTY", 0.018, "grey"] call _make;
            } else {
                private _picture = getText (configFile >> "CfgWeapons" >> _class >> "picture");
                ["PMCS_Picture", [0.022, _y + 0.026, 0.08, 0.066], controlNull, "tech", [_picture, "\pmc_shop\data\noimage_ca.paa"] select (_picture == "")] call _make;
                ["PMCS_TextBold", [0.108, _y + 0.026, 0.175, 0.026], controlNull, "tech", _class call _weaponName, 0.017] call _make;
                private _count = count ([_forEachIndex, _class] call _offersOf);
                ["PMCS_Text", [0.108, _y + 0.051, 0.175, 0.022], controlNull, "tech", [localize "STR_PMCS_TECH_NONE_SHORT", format [localize "STR_PMCS_TECH_COUNT", _count]] select (_count > 0),
                    0.014, ["grey", "green"] select (_count > 0)] call _make;
                ["PMCS_Text", [0.108, _y + 0.072, 0.175, 0.02], controlNull, "tech", _class, 0.012, "grey"] call _make;
                [["PMCS_ButtonClear", [0.015, _y, 0.27, 0.098], controlNull, "tech"] call _make, "slot", [_forEachIndex]] call _click;
            };
        } forEach _carried;
        // What the gunsmith takes from the inventory, and how much of it the player has.
        private _items = items player;
        private _haveOf = {private _c = _this; {_x == _c} count _items};
        ["PMCS_TextBold", [0.015, 0.625, 0.27, 0.026], controlNull, "tech", localize "STR_PMCS_TECH_PARTS", 0.016, "grey"] call _make;
        {
            _x params ["_label", "_class"];
            private _y = 0.652 + _forEachIndex * 0.03;
            ["PMCS_Text", [0.015, _y, 0.2, 0.028], controlNull, "tech", localize _label, 0.016] call _make;
            ["PMCS_TextBoldRight", [0.2, _y, 0.085, 0.028], controlNull, "tech", str (_class call _haveOf), 0.018] call _make;
        } forEach [["STR_PMCS_PART_LOW", (call PMCS_fnc_parts) select 0], ["STR_PMCS_PART_MED", (call PMCS_fnc_parts) select 1],
            ["STR_PMCS_PART_HIGH", (call PMCS_fnc_parts) select 2], ["STR_PMCS_ITEM_BELT", (call PMCS_fnc_gearItems) select 0],
            ["STR_PMCS_ITEM_UNIFORM", (call PMCS_fnc_gearItems) select 1]];
        ["PMCS_Text", [0.015, 0.81, 0.27, 0.13], controlNull, "tech", localize "STR_PMCS_TECH_NOTE", 0.013, "grey"] call _make;
        // The upgrades of the chosen weapon or vest, each as [key, target, kind, operation,
        // price, needs [[label, have, need], ...], upgrades after it].
        private _current = _carried select _slot;
        ["PMCS_TextBold", [0.315, 0.155, 0.67, 0.04], controlNull, "tech", [localize "STR_PMCS_TECH_TITLE", format [localize "STR_PMCS_TECH_TITLE_FOR", _current call _weaponName]] select (_current != ""),
            0.026] call _make;
        private _group = PMCS_ui get "techGroup";
        private _offers = [_slot, _current] call _offersOf;
        if (_offers isEqualTo []) exitWith {
            ["PMCS_Text", [0.315, 0.215, 0.67, 0.08], _group, "tech", localize (["STR_PMCS_TECH_NO_WEAPON", "STR_PMCS_TECH_NONE"] select (_current != "")), 0.019, "grey"] call _make;
        };
        private _entries = if (_slot == 3) then {
            _offers apply {
                _x params ["_upgrade", "_target"];
                private _kind = _upgrade select 5;
                [_upgrade select 0, _target, localize (switch (_kind) do {case "belt": {"STR_PMCS_KIND_BELT"}; case "rev": {"STR_PMCS_KIND_REV"}; default {"STR_PMCS_KIND_ROLE"}}),
                    _upgrade select 2, _upgrade select 6,
                    ([_upgrade] call PMCS_fnc_gearTake) apply {[(_x select 0) call PMCS_fnc_itemTitle, (_x select 0) call _haveOf, _x select 1]},
                    count (([_target] call PMCS_fnc_gearUpgradesFor) select {((_x select 0) select 5) != "rev"}), _kind == "belt", _kind == "rev",
                    (_upgrade param [11, []]) apply {format ["+%1 ×%2", (_x select 0) call PMCS_fnc_itemTitle, _x select 1]}]
            }
        } else {
            _offers apply {
                _x params ["_upgrade", "_target"];
                private _needs = [];
                {
                    private _need = (_upgrade select 6) param [_forEachIndex, 0];
                    if (_need > 0) then {_needs pushBack [localize (["STR_PMCS_PART_SHORT_LOW", "STR_PMCS_PART_SHORT_MED", "STR_PMCS_PART_SHORT_HIGH"] select _forEachIndex), _x call _haveOf, _need]};
                } forEach (call PMCS_fnc_parts);
                private _kind = _upgrade select 3;
                [_upgrade select 0, _target, localize (switch (_kind) do {case "gl": {"STR_PMCS_KIND_GL"}; case "rev": {"STR_PMCS_KIND_REV"}; default {"STR_PMCS_KIND_UP"}}),
                    _upgrade select 4, _upgrade select 5, _needs, count (([_target] call PMCS_fnc_upgradesFor) select {((_x select 0) select 3) != "rev"}),
                    _kind == "gl", _kind == "rev", []]
            }
        };
        // Upgrades first, then the undo entries.
        _entries = (_entries select {!(_x select 8)}) + (_entries select {_x select 8});
        (PMCS_ui get "bank") params ["_personal", "_group2"];
        private _balance = [_personal, _group2] select ((PMCS_ui get "account") == "group");
        private _armed = PMCS_ui getOrDefault ["techArmed", ["", -1]];
        private _busy = PMCS_ui getOrDefault ["techBusy", false];
        {
            _x params ["_key", "_target", "_kind", "_op", "_price", "_needs", "_next", "_accent", "_undo", "_gives"];
            private _y = 0.21 + _forEachIndex * 0.16;
            ["PMCS_Text", [0.315, _y, 0.67, 0.15], _group, "tech", "", 0.02, "", "white"] call _make;
            ["PMCS_Text", [0.322, _y + 0.01, 0.13, 0.13], _group, "tech", "", 0.02, "", "photo"] call _make;
            private _picture = getText (configFile >> "CfgWeapons" >> _target >> "picture");
            ["PMCS_Picture", [0.326, _y + 0.02, 0.122, 0.11], _group, "tech", [_picture, "\pmc_shop\data\noimage_ca.paa"] select (_picture == "")] call _make;
            ["PMCS_TextBold", [0.465, _y + 0.012, 0.33, 0.032], _group, "tech", _target call _weaponName, 0.021] call _make;
            ["PMCS_Text", [0.465, _y + 0.044, 0.33, 0.026], _group, "tech", format ["%1 · %2", _kind, _op], 0.015, ["grey", "orangeDark"] select _accent] call _make;
            if (_undo) then {["PMCS_Text", [0.315, _y, 0.004, 0.15], _group, "tech", "", 0.02, "", "navy"] call _make};
            // Cost: the money (when there is any), then each item as have / need, red where short.
            private _short = _price > _balance;
            private _cost = [];
            if (_undo) then {
                _cost pushBack format ["<t font='RobotoCondensedBold' color='#2f5f2a'>%1</t>", localize "STR_PMCS_TECH_FREE"];
                {_cost pushBack format ["<t color='#2f5f2a'>%1</t>", _x]} forEach _gives;
            } else {
                if (_price > 0 || {_needs isEqualTo []}) then {
                    _cost pushBack format ["<t font='RobotoCondensedBold' color='%1'>%2</t>", ["#2f5f2a", "#9e291f"] select (_price > _balance), _price call _money];
                };
            };
            {
                _x params ["_label", "_have", "_need"];
                private _missing = _have < _need;
                if (_missing) then {_short = true};
                _cost pushBack format ["<t color='%1'>%2 %3/%4</t>", ["#4a5056", "#9e291f"] select _missing, _label, _have, _need];
            } forEach _needs;
            ["PMCS_Struct", [0.465, _y + 0.072, 0.33, 0.035], _group, "tech", _cost joinString "   ", 0.017] call _make;
            if (_next > 0) then {["PMCS_Text", [0.465, _y + 0.108, 0.33, 0.024], _group, "tech", format [localize "STR_PMCS_TECH_NEXT", _next], 0.014, "grey"] call _make};
            private _isArmed = (_armed select 0) == _key && {diag_tickTime - (_armed select 1) < 5};
            private _label = if (_isArmed) then {format [localize "STR_PMCS_TECH_CONFIRM", [_price call _money, localize "STR_PMCS_TECH_FREE"] select _undo]} else {
                localize (["STR_PMCS_TECH_DO", "STR_PMCS_TECH_UNDO"] select _undo)
            };
            private _button = [["PMCS_Button", [0.81, _y + 0.05, 0.165, 0.05], _group, "tech", _label, 0.018, "white",
                if (_isArmed) then {"red"} else {["orangeDark", "navy"] select _undo}] call _make, "upgrade", [_key]] call _click;
            _button ctrlEnable (!_short && {!_busy});
            if (_short) then {["PMCS_TextCenter", [0.81, _y + 0.104, 0.165, 0.024], _group, "tech", localize "STR_PMCS_TECH_SHORT", 0.014, "red"] call _make};
        } forEach _entries;
    };
    // The upgrade tree window: the families of weapons or vests on the left (by category),
    // the chosen family drawn on the right as cards joined by lines, the way back to the
    // left (base), each card with what the upgrade into it costs.
    case "tree": {
        if (_args isNotEqualTo []) then {PMCS_ui set ["treeOpen", _args select 0]};
        ["treeWin"] call PMCS_fnc_uiClear;
        if !(PMCS_ui getOrDefault ["treeOpen", false]) exitWith {};
        private _gearSide = PMCS_ui getOrDefault ["treeGear", (PMCS_ui getOrDefault ["techSlot", 0]) == 3];
        PMCS_ui set ["treeGear", _gearSide];
        ["PMCS_Text", [0.075, 0.155, 0.86, 0.79], controlNull, "treeWin", "", 0.02, "", [0, 0, 0, 0.25]] call _make;
        ["PMCS_Text", [0.08, 0.15, 0.85, 0.79], controlNull, "treeWin", "", 0.02, "", "white"] call _make;
        ["PMCS_TextBold", [0.095, 0.16, 0.3, 0.04], controlNull, "treeWin", localize "STR_PMCS_TREE_TITLE", 0.026] call _make;
        {
            _x params ["_label", "_value", "_x0"];
            private _on = _value isEqualTo _gearSide;
            [["PMCS_Button", [_x0, 0.165, 0.1, 0.034], controlNull, "treeWin", localize _label, 0.017, ["text", "white"] select _on, ["photo", "navy"] select _on] call _make,
                "treeSide", [_value]] call _click;
        } forEach [["STR_PMCS_TREE_WEAPONS", false, 0.36], ["STR_PMCS_TREE_VESTS", true, 0.465]];
        // Edges (upgrades only): [from, to, kind, cost, category, from state, to state, from class, to class].
        private _classOf = {params ["_pairs", "_i"]; private _p = _pairs select {!("*" in (_x select _i))}; if (_p isEqualTo []) then {""} else {(_p select 0) select _i}};
        private _edges = if (_gearSide) then {
            ((call PMCS_fnc_gearUpgrades) select {(_x select 5) != "rev"}) apply {
                private _cost = ([_x] call PMCS_fnc_gearTake) apply {format ["%1 ×%2", (_x select 0) call PMCS_fnc_itemTitle, _x select 1]};
                if ((_x select 6) > 0) then {_cost = [(_x select 6) call _money] + _cost};
                [_x select 1, _x select 2, ["role", "belt"] select ((_x select 5) == "belt"), _cost joinString ", ", _x select 14, _x select 12, _x select 13, _x select 3, _x select 4]
            }
        } else {
            ((call PMCS_fnc_upgrades) select {(_x select 3) != "rev"}) apply {
                private _parts = _x select 6;
                private _cost = [(_x select 5) call _money];
                {if ((_parts select _forEachIndex) > 0) then {_cost pushBack format ["%1 %2", localize _x, _parts select _forEachIndex]}} forEach
                    ["STR_PMCS_PART_SHORT_LOW", "STR_PMCS_PART_SHORT_MED", "STR_PMCS_PART_SHORT_HIGH"];
                [_x select 1, _x select 2, ["up", "gl"] select ((_x select 3) == "gl"), _cost joinString ", ", _x select 10, _x select 8, _x select 9,
                    [_x select 7, 0] call _classOf, [_x select 7, 1] call _classOf]
            }
        };
        // Families: names joined by upgrades; each named after its root (no upgrade into it).
        private _familyOf = createHashMap;
        {
            _x params ["_a", "_b"];
            private _fa = _familyOf getOrDefault [_a, [_a]];
            private _fb = _familyOf getOrDefault [_b, [_b]];
            if !(_fa isEqualTo _fb) then {
                {_fa pushBackUnique _x} forEach _fb;
                {_familyOf set [_x, _fa]} forEach _fa;
            } else {_familyOf set [_a, _fa]; _familyOf set [_b, _fa]};
        } forEach _edges;
        private _targets = _edges apply {_x select 1};
        private _families = [];
        {
            private _names = _y;
            if ((_families findIf {(_x select 2) isEqualTo _names}) < 0) then {
                private _roots = _names select {!(_x in _targets)};
                _roots sort true;
                private _root = [_roots param [0, _names select 0], _names select 0] select (_roots isEqualTo []);
                private _category = ((_edges select {(_x select 0) == _root}) param [0, ["", "", "", "", ""]]) select 4;
                _families pushBack [_category, _root, _names];
            };
        } forEach _familyOf;
        // The chosen item's family first time round.
        private _carried = [primaryWeapon player, secondaryWeapon player, handgunWeapon player, vest player];
        private _current = _carried select (PMCS_ui getOrDefault ["techSlot", 0]);
        private _currentName = if (_gearSide) then {
            (((call PMCS_fnc_gearUpgrades) select {toLower (_x select 3) == toLower _current}) apply {_x select 1}) param [0, ""]
        } else {
            (((call PMCS_fnc_upgrades) select {([_current, _x select 7] call PMCS_fnc_upgradeTarget) != ""}) apply {_x select 1}) param [0, ""]
        };
        private _chosen = PMCS_ui getOrDefault ["treeFamily", ""];
        if ((_families findIf {(_x select 1) == _chosen}) < 0) then {
            private _at = _families findIf {_currentName in (_x select 2)};
            _chosen = if (_at >= 0) then {(_families select _at) select 1} else {""};
        };
        // The list: categories in the shop's order, families by name.
        private _order = ("true" configClasses (configFile >> "CfgPMCShop" >> "Categories")) apply {getText (_x >> "source")};
        private _sorted = _families apply {[((_order find (_x select 0)) + 1000) % 1000, _x select 0, _x select 1, _x]};
        _sorted sort true;
        if (_chosen == "" && {_sorted isNotEqualTo []}) then {_chosen = (_sorted select 0) select 2};
        PMCS_ui set ["treeFamily", _chosen];
        private _list = ["PMCS_List", [0.095, 0.215, 0.2, 0.66], controlNull, "treeWin", "", 0.016] call _make;
        _list lnbSetColumnsPos [0];
        private _lastCategory = "-";
        {
            _x params ["", "_category", "_root"];
            if (_category != _lastCategory) then {
                private _head = _list lnbAddRow [[_category] call PMCS_fnc_categoryName];
                _list lnbSetColor [[_head, 0], ["grey"] call PMCS_fnc_uiColor];
                _list lnbSetData [[_head, 0], ""];
                _lastCategory = _category;
            };
            private _row = _list lnbAddRow ["  " + _root];
            _list lnbSetData [[_row, 0], _root];
            if (_root == _chosen) then {_list lnbSetCurSelRow _row};
        } forEach _sorted;
        _list ctrlAddEventHandler ["LBSelChanged", {
            params ["_ctrl", "_row"];
            private _family = _ctrl lnbData [_row, 0];
            if (_family != "" && {_family != (PMCS_ui get "treeFamily")}) then {PMCS_ui set ["treeFamily", _family]; ["tree"] call PMCS_fnc_uiTech};
        }];
        // The chosen family as a diagram: a column per step from its base version.
        private _family = (_families select {(_x select 1) == _chosen}) param [0, ["", "", []]];
        private _names = +(_family select 2);
        private _famEdges = _edges select {(_x select 0) in _names};
        private _depth = createHashMap;
        {_depth set [_x, 0]} forEach _names;
        for "_pass" from 1 to (count _names) do {
            {_depth set [_x select 1, (_depth get (_x select 1)) max ((_depth get (_x select 0)) + 1)]} forEach _famEdges;
        };
        private _columns = [];
        {
            private _d = _depth get _x;
            while {count _columns <= _d} do {_columns pushBack []};
            (_columns select _d) pushBack _x;
        } forEach _names;
        private _rowOf = createHashMap;
        {
            private _col = _x;
            private _keyed = _col apply {
                private _name = _x;
                private _parents = (_famEdges select {(_x select 1) == _name}) apply {_rowOf getOrDefault [_x select 0, 0]};
                [if (_parents isEqualTo []) then {0} else {selectMin _parents}, _name, _parents]
            };
            _keyed sort true;
            private _next = 0;
            {
                _x params ["_want", "_name", "_parents"];
                private _row = _next max ([_next, _want] select (_parents isNotEqualTo []));
                _rowOf set [_name, _row];
                _next = _row + 1;
            } forEach _keyed;
        } forEach _columns;
        // Card size: room for one line per upgrade leading into the card.
        private _maxIn = 0;
        {private _n = _x; _maxIn = _maxIn max ({(_x select 1) == _n} count _famEdges)} forEach _names;
        private _w = 0.17;
        private _h = 0.08 + 0.036 * _maxIn;
        private _gapX = 0.045;
        private _gapY = 0.016;
        private _x0 = 0.31;
        private _y0 = 0.215;
        private _group = ["PMCS_GroupWide", [_x0, _y0, 0.605, 0.66], controlNull, "treeWin"] call _make;
        private _pos = {params ["_name"]; [_x0 + 0.008 + (_depth get _name) * (_w + _gapX), _y0 + 0.008 + (_rowOf get _name) * (_h + _gapY)]};
        private _stateOf = createHashMap;
        private _classAt = createHashMap;
        {
            _stateOf set [_x select 0, _x select 5]; _stateOf set [_x select 1, _x select 6];
            if !((_x select 0) in _classAt) then {_classAt set [_x select 0, _x select 7]};
            _classAt set [_x select 1, _x select 8];
        } forEach _famEdges;
        private _stripe = {
            params ["_state"];
            switch (true) do {
                case (_state == "базовый"): {[0.184, 0.478, 0.243, 1]};
                case ("UGL" in _state || {"гренадер" in _state}): {[0.71, 0.337, 0.11, 1]};
                case ("пояс" in _state || {"дооснащен" in _state}): {[0.541, 0.392, 0.086, 1]};
                case (_state == "продвинутый" || {_state in ["стрелок", "командир"]}): {[0.184, 0.373, 0.62, 1]};
                case (_state == "уникальный" || {_state == "медик"}): {[0.42, 0.247, 0.569, 1]};
                default {[0.478, 0.51, 0.522, 1]};
            }
        };
        // Lines first, under the cards: right edge of the source, a turn halfway, left edge of the target.
        // Each line gets its own turn in the gap and its own height at both ends, so lines
        // that meet or part are told apart by colour.
        {
            _x params ["_from", "_to", "_kind"];
            ([_from] call _pos) params ["_ax", "_ay"];
            ([_to] call _pos) params ["_bx", "_by"];
            private _colour = [[0.184, 0.435, 0.561, 1], [0.769, 0.318, 0.122, 1]] select (_kind in ["gl", "belt"]);
            private _edge = _x;
            private _gap = _famEdges select {(_depth get (_x select 0)) == (_depth get _from)};
            private _outs = _famEdges select {(_x select 0) == _from};
            private _ins = _famEdges select {(_x select 1) == _to};
            private _y1 = _ay + 0.016 + 0.008 * (_outs find _edge);
            private _y2 = _by + 0.016 + 0.008 * (_ins find _edge);
            private _mx = _ax + _w + _gapX * ((_gap find _edge) + 1) / ((count _gap) + 1);
            ["PMCS_Text", [_ax + _w, _y1, _gapX / 2, 0.003], _group, "treeWin", "", 0.02, "", _colour] call _make;
            ["PMCS_Text", [_mx, (_y1 min _y2), 0.002, abs (_y2 - _y1) + 0.003], _group, "treeWin", "", 0.02, "", _colour] call _make;
            ["PMCS_Text", [_mx, _y2, _bx - _mx, 0.003], _group, "treeWin", "", 0.02, "", _colour] call _make;
            ["PMCS_Text", [_bx - 0.006, _y2 - 0.004, 0.006, 0.011], _group, "treeWin", "", 0.02, "", _colour] call _make;
        } forEach _famEdges;
        {
            private _name = _x;
            ([_name] call _pos) params ["_cx", "_cy"];
            private _state = _stateOf getOrDefault [_name, ""];
            if (_name == _currentName) then {["PMCS_Text", [_cx - 0.003, _cy - 0.005, _w + 0.006, _h + 0.01], _group, "treeWin", "", 0.02, "", "orange"] call _make};
            ["PMCS_Text", [_cx, _cy, _w, _h], _group, "treeWin", "", 0.02, "", "panel"] call _make;
            ["PMCS_Text", [_cx, _cy, 0.004, _h], _group, "treeWin", "", 0.02, "", [_state] call _stripe] call _make;
            private _picture = getText (configFile >> "CfgWeapons" >> (_classAt getOrDefault [_name, ""]) >> "picture");
            ["PMCS_Picture", [_cx + 0.008, _cy + 0.005, 0.045, 0.04], _group, "treeWin", [_picture, "\pmc_shop\data\noimage_ca.paa"] select (_picture == "")] call _make;
            ["PMCS_TextBold", [_cx + 0.056, _cy + 0.004, _w - 0.06, 0.024], _group, "treeWin", _name, 0.015] call _make;
            ["PMCS_Text", [_cx + 0.056, _cy + 0.026, _w - 0.06, 0.02], _group, "treeWin", _state, 0.013, "grey"] call _make;
            private _ins = _famEdges select {(_x select 1) == _name};
            {
                _x params ["_from", "", "_kind", "_cost"];
                private _tag = localize (switch (_kind) do {case "gl": {"STR_PMCS_KIND_GL"}; case "belt": {"STR_PMCS_KIND_BELT"}; case "role": {"STR_PMCS_KIND_ROLE"}; default {"STR_PMCS_KIND_UP"}});
                private _line = ["PMCS_Struct", [_cx + 0.008, _cy + 0.05 + _forEachIndex * 0.036, _w - 0.012, 0.036], _group, "treeWin",
                    format ["<t color='%1'>%2</t>%3<br/><t color='#1d2125'>%4</t>", ["#2f6f8f", "#b5561c"] select (_kind in ["gl", "belt"]), _tag,
                        ["", format [" · %1", _from]] select (count _ins > 1), _cost], 0.012] call _make;
                _line ctrlSetTooltip format ["%1 → %2: %3", _from, _name, _cost];
            } forEach _ins;
        } forEach _names;
        if (_names isEqualTo []) then {["PMCS_Text", [_x0 + 0.02, _y0 + 0.02, 0.5, 0.04], controlNull, "treeWin", localize "STR_PMCS_TECH_NONE", 0.018, "grey"] call _make};
        ["PMCS_Text", [0.095, 0.885, 0.6, 0.04], controlNull, "treeWin", localize "STR_PMCS_TREE_NOTE", 0.015, "grey"] call _make;
        [["PMCS_Button", [0.8, 0.885, 0.115, 0.042], controlNull, "treeWin", localize "STR_PMCS_CLOSE", 0.018, "text", "photo"] call _make, "tree", [false]] call _click;
    };
    case "treeSide": {
        PMCS_ui set ["treeGear", _args select 0];
        PMCS_ui set ["treeFamily", ""];
        ["tree"] call PMCS_fnc_uiTech;
    };
    case "slot": {
        PMCS_ui set ["techSlot", _args select 0];
        PMCS_ui set ["treeGear", (_args select 0) == 3];
        PMCS_ui set ["treeFamily", ""];
        PMCS_ui set ["techArmed", ["", -1]];
        ["body"] call PMCS_fnc_uiTech;
    };
    // The first click arms the button for 5 seconds; the second sends the upgrade.
    case "upgrade": {
        _args params ["_key"];
        private _armed = PMCS_ui getOrDefault ["techArmed", ["", -1]];
        if ((_armed select 0) != _key || {diag_tickTime - (_armed select 1) >= 5}) exitWith {
            PMCS_ui set ["techArmed", [_key, diag_tickTime]];
            ["body"] call PMCS_fnc_uiTech;
        };
        PMCS_ui set ["techArmed", ["", -1]];
        PMCS_ui set ["techBusy", true];
        private _slot = PMCS_ui getOrDefault ["techSlot", 0];
        if (_slot == 3) then {
            [player, PMCS_ui get "terminal", PMCS_ui get "account", _key] remoteExecCall ["PMCS_fnc_gearUpgrade", 2];
        } else {
            [player, PMCS_ui get "terminal", PMCS_ui get "account", _slot, _key] remoteExecCall ["PMCS_fnc_upgrade", 2];
        };
        ["toast", [localize "STR_PMCS_TECH_WORKING"]] call PMCS_fnc_ui;
        ["body"] call PMCS_fnc_uiTech;
    };
};
