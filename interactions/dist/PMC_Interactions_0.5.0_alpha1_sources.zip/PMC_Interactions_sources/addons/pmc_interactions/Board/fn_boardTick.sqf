// Per frame, client: feeds the mouse, advances the game, watches the situation,
// redraws, ends the game.
if (isNil "PMCI_board") exitWith {};
private _now = diag_tickTime;
private _dt = (_now - (PMCI_board get "last")) min 0.25;
PMCI_board set ["last", _now];
private _state = PMCI_board get "state";
private _game = PMCI_board get "game";
private _model = missionNamespace getVariable format ["PMCI_fnc_%1Model", _game];
// Mouse games: where the mouse is, how far it moved since the last frame, whether the
// button is held. Cleaning only counts the path while scrubbing.
if (_game in ["clean", "iv", "suture", "splint", "weld"]) then {
    private _mouse = call PMCI_fnc_boardMouse;
    (PMCI_board getOrDefault ["mouse", _mouse]) params ["_fromX", "_fromY"];
    private _distance = sqrt (((_mouse select 0) - _fromX) ^ 2 + ((_mouse select 1) - _fromY) ^ 2);
    private _held = PMCI_board getOrDefault ["scrubbing", false];
    if (_game == "clean") then {
        if (_held && {_distance > 0}) then {["scrub", _state, [_mouse select 0, _mouse select 1, _distance]] call _model};
    } else {
        ["mouse", _state, [_mouse select 0, _mouse select 1, _distance, _held, _dt]] call _model;
    };
    PMCI_board set ["mouse", _mouse];
};
["tick", _state, _dt] call _model;
PMCI_board set ["depth", 0 max ((PMCI_board get "depth") - _dt * 3)];
if !(call PMCI_fnc_boardValid) exitWith {[false] call PMCI_fnc_finish};
if ((_state get "status") != "running") exitWith {[(_state get "status") == "success"] call PMCI_fnc_finish};
call PMCI_fnc_boardDraw;
