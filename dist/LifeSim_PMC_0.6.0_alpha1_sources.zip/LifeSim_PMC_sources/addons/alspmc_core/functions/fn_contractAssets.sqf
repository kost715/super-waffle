// Discover installed assets once. Never require a guessed 3CB classname.
private _cached = missionNamespace getVariable ["ALSPMC_contractAssets", createHashMap];
if (count _cached > 0) exitWith {_cached};
private _preferred = (getArray (configFile >> "ALSPMC_Settings" >> "banditFactions")) apply {toLowerANSI _x};
private _militia = [];
private _modMen = [];
{
    private _name = configName _x;
    if ((toLowerANSI _name find "uk3cb_") == 0 && {getNumber (_x >> "scope") == 2} && {_name isKindOf "CAManBase"}) then {
        private _armed = (getArray (_x >> "weapons")) findIf {getNumber (configFile >> "CfgWeapons" >> _x >> "type") in [1,2]};
        if (_armed >= 0) then {
            _modMen pushBack _name;
            if ((toLowerANSI getText (_x >> "faction")) in _preferred) then {_militia pushBack _name};
        };
    };
} forEach ("true" configClasses (configFile >> "CfgVehicles"));
if (_militia isEqualTo []) then {_militia = +_modMen};
private _fallback = ["I_G_Soldier_F", "I_G_Soldier_lite_F", "O_G_Soldier_F"] select {isClass (configFile >> "CfgVehicles" >> _x)};
if (_militia isEqualTo []) then {_militia = _fallback};
private _pools = [[],[],[],[]];
{
    private _name = configName _x;
    private _lower = toLowerANSI _name;
    private _mod = (_lower find "uk3cb") == 0 || {(_lower find "rhs") == 0};
    if (_mod && {getNumber (_x >> "scope") == 2} && {getNumber (_x >> "type") in [1,2]} && {
        ((getArray (_x >> "muzzles")) findIf {!(_x in ["this", "This"])}) < 0
    }) then {
        private _type = getNumber (_x >> "type");
        private _mags = (getArray (_x >> "magazines")) select {isClass (configFile >> "CfgMagazines" >> _x)};
        if (_mags isNotEqualTo []) then {
            private _bucket = if (_type == 2) then {0} else {
                private _cursor = toLowerANSI getText (_x >> "cursor");
                if (_cursor in ["mg", "srifle"]) then {3} else {if (_cursor == "smg") then {1} else {2}}
            };
            (_pools select _bucket) pushBack [_name, _mags select 0];
        };
    };
} forEach ("true" configClasses (configFile >> "CfgWeapons"));
_cached = createHashMapFromArray [["militia", _militia], ["military", _modMen], ["weapons", _pools]];
ALSPMC_contractAssets = _cached;
_cached
