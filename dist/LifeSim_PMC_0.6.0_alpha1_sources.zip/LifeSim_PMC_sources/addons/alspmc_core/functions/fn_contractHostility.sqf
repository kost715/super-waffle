// Positive-rated groups never become renegades. Lease directed hostility to
// actual player sides; native lawOutlawLocal can move them to EAST. Never
// change a player's rating, captive state, group or wanted logic.
params ["_action", "_job"];
private _leases = missionNamespace getVariable ["ALSPMC_hostileContracts", createHashMap];
private _relations = missionNamespace getVariable ["ALSPMC_hostileRelations", createHashMap];
private _id = _job get "alspmcQuestId";
private _targets = (allPlayers select {isPlayer _x && {alive _x}});
private _sides = (_targets apply {side group _x}) arrayIntersect [civilian, east, west, resistance];
_sides pushBackUnique civilian;
private _oldSide = _job getOrDefault ["alspmcEnemySide", east];
private _side = _oldSide;
if (_side in _sides) then {_side = ([east, resistance, west] select {!(_x in _sides)}) param [0, sideUnknown]};
if (_action != "release" && {_side == sideUnknown}) exitWith {false};
if (_action != "release") then {
    createCenter _side;
    if (_oldSide != _side) then {
        private _groups = _job getOrDefault ["alspmcGroups", []];
        {
            if (!isNull _x && {side _x == _oldSide}) then {
                private _new = createGroup [_side, true];
                if (!isNull _new) then {
                    (units _x) joinSilent _new; deleteGroup _x;
                    _new setBehaviour "COMBAT"; _new setCombatMode "RED";
                    [_new, _job getOrDefault ["alspmcSite", _job get "pos"]] call BIS_fnc_taskAttack;
                    _groups set [_forEachIndex, _new];
                };
            };
        } forEach +_groups;
    };
    _job set ["alspmcEnemySide", _side];
};
if (_action == "side") exitWith {_side};
if (_action == "release") then {_leases deleteAt _id} else {_leases set [_id, _sides apply {[_side, _x]}]};
// Restore unused directed pairs only if another system has not changed them.
{
    private _saved = _relations get _x;
    _saved params ["_from", "_to", "_before"];
    if (((values _leases) findIf {[_from, _to] in _x}) < 0) then {
        if ((_from getFriend _to) == 0) then {_from setFriend [_to, _before]};
        _relations deleteAt _x;
    };
} forEach keys _relations;
{
    _x params ["_from", "_to"];
    private _key = str _x;
    if !(_key in _relations) then {_relations set [_key, [_from, _to, _from getFriend _to]]};
    _from setFriend [_to, 0];
} forEach (_leases getOrDefault [_id, []]);
ALSPMC_hostileContracts = _leases; ALSPMC_hostileRelations = _relations;
if (_action == "tick") then {
    private _living = [_job] call ALSPMC_fnc_contractTeam;
    private _protected = _job getOrDefault ["alspmcProtected", objNull];
    if (!isNull _protected && {alive _protected}) then {_living pushBack _protected};
    private _truck = _job getOrDefault ["alspmcTruck", objNull];
    if (!isNull _truck && {alive _truck}) then {_living pushBack _truck};
    {
        if (!isNull _x && {side _x == _side}) then {
            {
                private _enemy = _x;
                if (alive _enemy) then {
                    private _nearest = objNull;
                    private _distance = 500;
                    {private _d = _enemy distance2D _x; if (_d < _distance) then {_nearest = _x; _distance = _d}} forEach _living;
                    if (!isNull _nearest) then {
                        _enemy reveal [_nearest, 4]; _enemy doTarget _nearest; _enemy doFire _nearest;
                    };
                };
            } forEach units _x;
        };
    } forEach (_job getOrDefault ["alspmcGroups", []]);
};
true
