// Pause only the leased base's streaming/capture logic. Original code runs for
// every other base, with original arguments/result; the registry is restored
// before the scheduler can switch to another script.
private _out = nil;
isNil {
    private _leases = missionNamespace getVariable ["ALSPMC_garrisonLeases", createHashMap];
    private _bases = ALS_war get "bases";
    ALS_war set ["bases", _bases select {!((_x select 0) in _leases)}];
    _out = _this call ALSPMC_nativeWarBases;
    ALS_war set ["bases", _bases];
    if (count _leases > 0) then {publicVariable "ALS_war"};
    true
};
_out
