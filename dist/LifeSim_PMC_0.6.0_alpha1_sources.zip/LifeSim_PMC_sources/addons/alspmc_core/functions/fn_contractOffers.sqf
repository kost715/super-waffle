// A founder's board is stable across devices, refreshes and successful accepts.
// Consumption never rerolls it. Stale tickets cannot start another mission.
params ["_unit"];
private _uid = [_unit] call ALS_fnc_uid;
private _boards = missionNamespace getVariable ["ALSPMC_contractBoards", createHashMap];
private _board = _boards getOrDefault [_uid, createHashMap];
if (count _board > 0 && {diag_tickTime < (_board get "expires")}) exitWith {_board};
private _level = ([_uid] call ALSPMC_fnc_contractProfile) get "level";
private _catalog = (call ALSPMC_fnc_contractCatalog) select {(_x select 3) <= _level};
private _army = count (["army"] call ALSPMC_fnc_contractSites);
private _government = count (["government"] call ALSPMC_fnc_contractSites);
private _commercial = count (["commercial"] call ALSPMC_fnc_contractSites);
private _bases = count (["assaultBase"] call ALSPMC_fnc_contractSites);
_catalog = _catalog select {
    switch (_x select 0) do {
        case "gov_convoy": {_army > 0 && {_army + _government > 1}};
        case "gov_guard": {_government > 0};
        case "gov_base": {_bases > 0};
        case "private_guard": {_commercial > 0};
        case "private_convoy";
        case "private_vip": {_commercial > 1};
        default {true};
    }
};
private _offers = [];
private _seq = (missionNamespace getVariable ["ALSPMC_boardSequence", 0]) + 1;
ALSPMC_boardSequence = _seq;
{
    _x params ["_category", "_setting", "_maximum"];
    private _candidates = _catalog select {(_x select 1) == _category};
    private _count = (round getNumber (configFile >> "ALSPMC_Settings" >> _setting)) max 1 min _maximum;
    for "_i" from 1 to (_count min count _candidates) do {
        private _chosen = floor random count _candidates;
        private _entry = _candidates deleteAt _chosen;
        _offers pushBack ["o" + str _seq + "_" + (_entry select 0), _entry select 0];
    };
} forEach [["government", "contractPoolGovernment", 6], ["private", "contractPoolPrivate", 2]];
private _ttl = (getNumber (configFile >> "ALSPMC_Settings" >> "contractPoolSeconds")) max 300 min 3600;
_board = createHashMapFromArray [["expires", diag_tickTime + _ttl], ["offers", _offers]];
_boards set [_uid, _board]; ALSPMC_contractBoards = _boards;
_board
