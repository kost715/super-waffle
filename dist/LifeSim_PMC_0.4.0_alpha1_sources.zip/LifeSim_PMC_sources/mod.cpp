name = "LifeSim PMC - Headquarters 0.4.0 alpha 1";
author = "LifeSim PMC project";
description = "Optional PMC headquarters, desktop management and test contract for Arma LifeSim 0.10.1.";
tooltip = "LifeSim PMC";
overview = "Optional addon: a PMC establishment licence and a warehouse base, both 1 euro for testing. Requires Arma LifeSim, CBA and ACE.";
