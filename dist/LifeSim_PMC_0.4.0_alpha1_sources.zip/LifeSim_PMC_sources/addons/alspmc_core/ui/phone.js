/* Added through LifeSim's app registry; no native HTML or state is replaced.
 * The PBO builder escapes non-ASCII source characters for Arma's ExecJS bridge.
 * Names and place names cross that bridge as UTF-8 byte arrays. */
(() => {
  "use strict";
  if (window.ALSPMCPhone) return;
  const id = "alspmc";
  let state = null, draft = "", dirty = false, pending = null, busy = null;
  let questTab = "available";
  // Separate reopened browser instances from the last server acknowledgement.
  let sequence = Math.floor(Date.now() % 900000000), notice = "", requestTimer;
  const dom = key => document.getElementById("alspmc-" + key);
  const text = bytes => {
    try { return new TextDecoder("utf-8", {fatal: true}).decode(new Uint8Array(bytes || [])); }
    catch (_) { return ""; }
  };
  const money = n => Math.round(n || 0).toLocaleString("ru-RU") + " €";
  const node = (tag, cls, value) => {
    const el = document.createElement(tag);
    if (cls) el.className = cls;
    if (value !== undefined) el.textContent = value;
    return el;
  };
  function button(label, op, key, disabled = false, danger = false) {
    const el = node("button", "btn " + (danger ? "danger" : "ghost"), label);
    el.dataset.alspmcOp = op;
    if (key) el.dataset.alspmcKey = key;
    el.disabled = disabled || !!busy;
    return el;
  }
  function request(op, extra = {}) {
    const token = ++sequence;
    busy = {op, token};
    clearTimeout(requestTimer);
    requestTimer = setTimeout(() => {
      if (!busy || busy.token !== token) return;
      busy = null;
      notice = "Ответ сервера задерживается. Обновите статус перед повторным действием.";
      render();
    }, 10000);
    send({a: "alspmc", op, token, ...extra});
    render();
  }
  function showConfirm(op, key) {
    pending = {op, key};
    render();
    dom("confirm").scrollIntoView({block: "nearest"});
  }
  function renderBases() {
    const list = dom("bases");
    list.replaceChildren();
    const bases = state.bases || [];
    dom("base-status").textContent = bases.length ? "База оформлена" : "База ещё не приобретена";
    for (const base of bases) {
      const card = node("div", "alspmc-site");
      card.append(node("div", "cargo", text(base.name) || "База ЧВК"));
      card.append(node("div", "note", text(base.town) + " · " + base.grid));
      card.append(node("div", "note", "Стоимость: " + money(base.price) + " · " + (base.locked ? "Двери закрыты" : "Двери открыты")));
      const actions = node("div", "meta");
      actions.append(button("На карте", "mark", base.key), button("Осмотреть", "view", base.key));
      actions.append(button(base.locked ? "Открыть двери" : "Запереть двери", base.locked ? "unlock" : "lock", base.key));
      actions.append(button("Обставить", "furnish", base.key, !base.near));
      if (base.canSell) actions.append(button("Продать базу", "sell", base.key, false, true));
      card.append(actions);
      list.append(card);
    }
    const nearby = dom("nearby");
    nearby.replaceChildren();
    if (state.hasOwnBase) return;
    nearby.append(node("div", "note", "Подойдите к свободному складу или ангару. Здесь появятся подходящие объекты в радиусе 40 м."));
    for (const site of state.nearby || []) {
      const card = node("div", "alspmc-site");
      card.append(node("div", "cargo", "Промышленный объект · " + site.grid));
      card.append(node("div", "note", text(site.town) + " · " + site.area + " м² · " + site.distance + " м"));
      card.append(button("Купить под базу · " + money(state.basePrice), "base", site.key,
        !state.licensed || state.cash + state.bank < state.basePrice));
      nearby.append(card);
    }
  }
  const questReasons = {
    unavailable: "Контракты временно недоступны. Проверьте журнал сервера.",
    license: "Сначала оформите лицензию ЧВК.", base: "Основателю нужна действующая база ЧВК.",
    leader: "Принять контракт может руководитель вашей группы с собственной ЧВК.",
    busy: "Сначала завершите текущее задание группы.", size: "Для теста допускается до четырёх участников.",
    active: "Сначала завершите или отмените активный контракт.",
    killed: "Цель устранена участником контракта.", outsider: "Цель погибла без зачёта участнику контракта. Выплаты нет.",
    lost: "Цель потеряна или удалена. Выплаты нет.", timeout: "Время контракта истекло. Выплаты нет.",
    cancelled: "Контракт отменён руководителем. Выплаты нет.", restart: "Прерван перезапуском мира. Выплаты нет; можно начать снова.",
    empty: "В группе не осталось подключённых игроков. Выплаты нет."
  };
  const questStatuses = {done: "Выполнен", failed: "Провален", cancelled: "Отменён", interrupted: "Прерван"};
  function renderQuests() {
    const q = state.quests || {}, list = dom("quests");
    const active = q.active && q.active.id ? q.active : null;
    list.replaceChildren();
    dom("quest-tabs").querySelectorAll("button").forEach(b => {
      b.disabled = !!busy;
      b.setAttribute("aria-pressed", String(b.dataset.alspmcKey === questTab));
    });
    if (questTab === "available") {
      list.append(node("div", "cargo", "Устранить цель · тестовый контракт"));
      list.append(node("div", "note", "Один вооружённый противник появится в случайном месте на суше в " + (q.minDistance || 600) + "–" + (q.maxDistance || 2000) + " м от вас. Положение будет отмечено на карте. Время: " + Math.round((q.timeout || 1800) / 60) + " мин."));
      list.append(node("div", "note", "Соло или группа до 4 игроков. Общая награда: " + money(q.pay) + ". LifeSim распределит её между участниками либо перечислит на счёт штатной компании по её настройкам."));
      list.append(node("div", "note", "Для зачёта цель должен убить участник, состоявший в группе при принятии и остающийся в ней. Соберите группу заранее через приложение LifeSim."));
      if (!q.canStart) list.append(node("div", "note", questReasons[q.reason] || "Данные контрактов ещё не загружены."));
      list.append(button("Принять контракт", "questStart", "eliminate", !q.canStart));
    } else if (questTab === "active") {
      if (!active) return list.append(node("div", "note", "Активного контракта нет."));
      list.append(node("div", "cargo", "Устранить цель · " + active.id));
      list.append(node("div", "note", "Цель: 0 / 1 · квадрат " + active.grid + " · участников: " + active.teamSize));
      const left = Math.max(0, Math.ceil(active.left || 0));
      list.append(node("div", "note", "Осталось: " + Math.floor(left / 60) + ":" + String(left % 60).padStart(2, "0") + " · общий фонд: " + money(active.pay)));
      const actions = node("div", "meta");
      if (active.canMap) actions.append(button("Цель на карте", "questMap", active.id));
      if (active.canCancel) actions.append(button("Отменить контракт", "questCancel", active.id, false, true));
      list.append(actions);
    } else {
      for (const record of q.history || []) {
        const card = node("div", "alspmc-site");
        card.append(node("div", "cargo", "Устранить цель · " + record.id + " · " + (questStatuses[record.status] || record.status)));
        card.append(node("div", "note", questReasons[record.reason] || "Контракт завершён."));
        if (record.status === "done") card.append(node("div", "note", "Фонд выплаты LifeSim: " + money(record.pay) + " · участников: " + record.teamSize));
        list.append(card);
      }
      if (!(q.history || []).length) list.append(node("div", "note", "Завершённых контрактов пока нет."));
    }
  }
  function render() {
    if (!dom("body")) return;
    dom("loading").hidden = !!state;
    dom("body").hidden = !state;
    if (!state) return;
    const currentName = text(state.name);
    dom("title").textContent = currentName || "Ваша ЧВК";
    dom("progress").textContent = state.hasOwnBase ? "Лицензия и база оформлены" : state.licensed ? "Лицензия получена — выберите базу" : "Начните с лицензии";
    dom("funds").textContent = "Доступно: " + money((state.cash || 0) + (state.bank || 0));
    dom("license-status").textContent = state.licensed ? "Лицензия получена" : "Лицензия на создание ЧВК";
    dom("license").hidden = state.licensed;
    dom("license").textContent = "Купить лицензию · " + money(state.licensePrice);
    dom("license").disabled = !!busy || !state.clerkNear || state.cash + state.bank < state.licensePrice;
    dom("license-note").textContent = state.licensed ? "Разрешение сохранено в лицензиях персонажа." : "Для оформления подойдите к клерку мэрии и откройте это приложение.";
    dom("notice").hidden = !notice;
    dom("notice").textContent = notice;
    const input = dom("name");
    if (!dirty && document.activeElement !== input) {
      draft = currentName;
      if (input.value !== draft) input.value = draft;
    }
    input.disabled = !state.canRename || !!busy;
    const count = Array.from(draft.trim().replace(/ +/g, " ")).length;
    dom("name-save").disabled = !state.canRename || !!busy || count < 3 || count > 40 || !dirty;
    dom("name-note").textContent = state.canRename ? "От 3 до 40 символов. Русские названия поддерживаются; переименование бесплатно." : "Название можно задать после покупки лицензии.";
    dom("refresh").disabled = !!busy;
    renderBases();
    renderQuests();
    dom("confirm").hidden = !pending;
    if (pending) {
      const what = pending.op === "license" ? "Оформить лицензию за " + money(state.licensePrice) + "?" :
        pending.op === "base" ? "Купить выбранный объект под базу за " + money(state.basePrice) + "?" :
        pending.op === "questStart" ? "Начать тестовый контракт? Весь состав группы нужно собрать до принятия. Общая награда — " + money((state.quests || {}).pay) + "." :
        pending.op === "questCancel" ? "Отменить текущий контракт без выплаты? Цель будет удалена." :
        "Продать базу через систему недвижимости LifeSim? За тестовое здание выплачивается 0 €, мебель и товары учитываются отдельно.";
      dom("confirm-text").textContent = what;
    }
  }
  app({
    id, title: "ЧВК", sub: "Управление",
    icon: ["g-alspmc", '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linejoin="round"><path d="M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6z"/><path d="M8 12l3 3 5-6"/></svg>'],
    shell: `<div id="alspmc-loading" class="empty">Загружаем данные ЧВК…</div>
      <div id="alspmc-body" hidden>
        <div class="card active" id="alspmc-section-summary"><div class="cargo" id="alspmc-title"></div><div class="note" id="alspmc-progress"></div><div class="note" id="alspmc-funds"></div></div>
        <div class="note alspmc-notice" id="alspmc-notice" role="status" hidden></div>
        <div class="card" id="alspmc-section-license"><div class="k">ЛИЦЕНЗИЯ</div><div class="cargo" id="alspmc-license-status"></div>
          <div class="note" id="alspmc-license-note"></div><div class="meta"><button class="btn" id="alspmc-license" data-alspmc-op="license"></button></div></div>
        <div class="card" id="alspmc-section-name"><div class="k">НАЗВАНИЕ ЧВК</div><label for="alspmc-name" class="note">Название организации</label>
          <input id="alspmc-name" maxlength="80" autocomplete="off" spellcheck="false" placeholder="Например, «Рубеж»">
          <div class="note" id="alspmc-name-note"></div><div class="meta"><button class="btn" id="alspmc-name-save" data-alspmc-op="name">Сохранить название</button></div></div>
        <div class="card" id="alspmc-section-base"><div class="k">БАЗА ЧВК</div><div class="cargo" id="alspmc-base-status"></div><div id="alspmc-bases"></div><div id="alspmc-nearby"></div></div>
        <div class="card" id="alspmc-section-quests"><div class="k">КОНТРАКТЫ ЧВК</div>
          <div class="meta" id="alspmc-quest-tabs"><button class="btn ghost" data-alspmc-op="questTab" data-alspmc-key="available">Доступные</button><button class="btn ghost" data-alspmc-op="questTab" data-alspmc-key="active">Активный</button><button class="btn ghost" data-alspmc-op="questTab" data-alspmc-key="history">История</button></div>
          <div id="alspmc-quests" class="alspmc-site"></div></div>
        <div class="card active" id="alspmc-confirm" hidden><div id="alspmc-confirm-text" class="note"></div><div class="meta"><button class="btn" data-alspmc-op="confirm">Подтвердить</button><button class="btn ghost" data-alspmc-op="cancel">Отмена</button></div></div>
        <div class="meta"><button class="btn ghost" id="alspmc-refresh" data-alspmc-op="status">Обновить статус</button></div>
      </div>`,
    render,
    open() { pending = null; send({a: "alspmc", op: "status", token: 0}); render(); },
    clicks: {"[data-alspmc-op]": b => {
      if (b.disabled) return;
      const op = b.dataset.alspmcOp, key = b.dataset.alspmcKey || "";
      if (op === "questTab") { questTab = key; return render(); }
      if (op === "cancel") { pending = null; return render(); }
      if (op === "confirm") {
        if (!pending || busy) return;
        const action = pending;
        pending = null;
        return request(action.op, {key: action.key});
      }
      if (["license", "base", "sell", "questStart", "questCancel"].includes(op)) return showConfirm(op, key);
      if (op === "name") return request("name", {name: Array.from(new TextEncoder().encode(draft))});
      if (["mark", "view", "furnish", "questMap"].includes(op)) return send({a: "alspmc", op, key});
      request(op, {key});
    }}
  });
  const root = document.getElementById("v-" + id);
  root.dataset.ruIgnore = "";
  const icon = document.querySelector('#grid [data-open="alspmc"]');
  if (icon) icon.dataset.ruIgnore = "";
  const crew = document.querySelector('#grid [data-open="crew"]');
  if (crew && icon) crew.after(icon);
  const style = node("style");
  style.textContent = `.g-alspmc{background:linear-gradient(155deg,#688e83,#1f4d42)}
    #v-alspmc [hidden]{display:none!important} #v-alspmc .k{color:var(--accent);font-size:1.2vh;letter-spacing:.08em;margin-bottom:.7vh}
    #v-alspmc .cargo{overflow-wrap:anywhere} #v-alspmc .meta{flex-wrap:wrap;gap:.7vh}
    #v-alspmc .alspmc-site{padding:1.2vh 0;border-top:.1vh solid var(--line);margin-top:1vh}
    #v-alspmc .btn{white-space:normal;text-align:center} #v-alspmc input{display:block;user-select:text;width:100%;box-sizing:border-box;margin-top:.8vh;padding:1.2vh;border-radius:1vh;border:.1vh solid var(--line);background:var(--panel2);color:var(--text);font:inherit}
    #v-alspmc .btn:disabled{opacity:.45;cursor:default}
    #v-alspmc [aria-pressed=true]{border-color:var(--accent);color:var(--accent)}
    #v-alspmc input:focus{outline:.15vh solid var(--accent)} #v-alspmc input:disabled{opacity:.6}
    #v-alspmc .alspmc-notice{padding:1.2vh;border:1px solid var(--accent);border-radius:1vh;margin-bottom:1vh}`;
  if (!window.ALSPMCDesktop) document.head.append(style);
  dom("name").addEventListener("input", e => {draft = e.target.value; dirty = true; render();});
  window.ALSPMCPhone = {
    set(next) {
      const wasActive = state && state.quests && state.quests.active && state.quests.active.id;
      const isActive = next.quests && next.quests.active && next.quests.active.id;
      if (wasActive && !isActive) questTab = "history";
      if (busy && next.reply === busy.token && busy.op === "questStart" && next.ok) questTab = "active";
      state = next;
      if (busy && next.reply === busy.token) {
        if (busy.op === "name" && next.ok) dirty = false;
        if (!next.ok) notice = ["questStart", "questCancel"].includes(busy.op) ?
          "Действие с контрактом не выполнено. Обновите статус и проверьте условия. Если не найдено место на суше, переместитесь и попробуйте снова." :
          "Действие не выполнено. Проверьте лицензию, деньги и доступность объекта.";
        busy = null;
        clearTimeout(requestTimer);
      }
      render();
      if (window.ALSPMCDesktop) ALSPMCDesktop.onState(next);
    },
    notice(bytes) { notice = text(bytes); render(); }
  };
})();
