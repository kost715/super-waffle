params ["_dead", "_killer", ["_instigator", objNull]];
if (!isServer || {!(missionNamespace getVariable ["ALSPMC_questsReady", false])}) exitWith {};
private _tag = _dead getVariable ["ALSPMC_questTarget", []];
if (count _tag != 2) exitWith {};
private _job = ALS_coopJobs getOrDefault [_tag select 0, createHashMap];
if ((_job getOrDefault ["alspmcQuestId", -1]) != (_tag select 1) || {
    (_job getOrDefault ["alspmcTarget", objNull]) != _dead
} || {alive _dead} || {(_job getOrDefault ["alspmcResult", ""]) != ""}) exitWith {};
if (time - (_job get "since") > (_job get "alspmcTimeout")) exitWith {_job set ["alspmcResult", "timeout"]};
private _by = _instigator;
if (isNull _by) then {_by = if (!isNull _killer && {!(_killer isKindOf "CAManBase")}) then {driver _killer} else {_killer}};
private _crew = ALS_crews getOrDefault [_job get "crew", createHashMap];
private _uid = if (isNull _by || {!isPlayer _by}) then {""} else {[_by] call ALS_fnc_uid};
private _credited = _uid in (_job get "team") && {_uid in (_crew getOrDefault ["members", []])};
_job set ["alspmcResult", ["outsider", "killed"] select _credited];
