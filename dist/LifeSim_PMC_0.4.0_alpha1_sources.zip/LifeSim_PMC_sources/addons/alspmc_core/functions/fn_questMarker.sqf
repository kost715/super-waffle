// Own local marker follows the native job mirror, even with phone/PC closed.
private _job = player getVariable ["ALS_coopJob", createHashMap];
if !(_job getOrDefault ["alspmc", false]) exitWith {
    if (missionNamespace getVariable ["ALSPMC_questMarkerOn", false]) then {
        deleteMarkerLocal "ALSPMC_contractTarget";
        ALSPMC_questMarkerOn = false;
    };
};
private _pos = _job getOrDefault ["pos", []];
if (count _pos != 3) exitWith {};
if !(missionNamespace getVariable ["ALSPMC_questMarkerOn", false]) then {
    createMarkerLocal ["ALSPMC_contractTarget", _pos];
    "ALSPMC_contractTarget" setMarkerTypeLocal "mil_objective";
    "ALSPMC_contractTarget" setMarkerColorLocal "ColorRed";
    "ALSPMC_contractTarget" setMarkerTextLocal (localize "STR_ALSPMC_quest_target");
    ALSPMC_questMarkerOn = true;
};
"ALSPMC_contractTarget" setMarkerPosLocal _pos;
