params ["_unit", "_op", "_arg", "_token"];
if !([_unit] call ALSPMC_fnc_requestAllowed) exitWith {false};
if (!(missionNamespace getVariable ["ALSPMC_questsReady", false]) || {!(_arg isEqualType "")} || {_token <= 0}) exitWith {false};
private _uid = [_unit] call ALS_fnc_uid;
private _cache = ALSPMC_questRequests getOrDefault [_uid, []];
private _seen = _cache findIf {(_x select 0) == _token};
if (_seen >= 0) exitWith {
    private _old = _cache select _seen;
    (_old select 1) == _op && {(_old select 2) == _arg} && {_old select 3}
};
private _ok = false;
isNil {
    private _crew = [_uid] call ALS_fnc_crewOf;
    if (_op == "questCancel") exitWith {
        private _job = ALS_coopJobs getOrDefault [_crew getOrDefault ["job", -1], createHashMap];
        if ((_crew getOrDefault ["leader", ""]) != _uid || {
            !("alspmcQuestId" in _job)
        } || {"q" + str (_job get "alspmcQuestId") != _arg} || {
            _job getOrDefault ["alspmcEnded", false]
        } || {(_job getOrDefault ["alspmcResult", ""]) != ""}) exitWith {};
        _job set ["alspmcResult", "cancelled"];
        [_job, 0] call ALS_fnc_coopEnd;
        _ok = true;
    };
    if (_op != "questStart" || {_arg != "eliminate"}) exitWith {};
    private _state = [_unit] call ALSPMC_fnc_questState;
    if !(_state get "canStart") exitWith {};
    private _pos = [_unit] call ALSPMC_fnc_questSite;
    if (_pos isEqualTo []) exitWith {
        ["STR_ALSPMC_quest_no_site"] remoteExecCall ["ALSPMC_fnc_message", _unit];
    };
    private _createdCrew = count _crew == 0;
    if (_createdCrew) then {
        // Same valid one-member schema as native crewDo's initial invitation.
        ALS_crewSeq = ALS_crewSeq + 1;
        _crew = createHashMapFromArray [["id", "c" + str ALS_crewSeq], ["leader", _uid], ["members", [_uid]], ["job", -1]];
        ALS_crews set [_crew get "id", _crew];
    };
    ALS_coopSeq = ALS_coopSeq + 1;
    ALSPMC_questSequence = ALSPMC_questSequence + 1;
    private _qid = ALSPMC_questSequence;
    private _team = (_crew get "members") select {!isNull ([_x] call ALS_fnc_findPlayer)};
    private _pay = _state get "pay";
    ALSPMC_questRecords set [_qid, [_uid, "starting", _pay, _pos, +_team, date, [], ""]];
    private _offer = createHashMapFromArray [
        ["id", ALS_coopSeq], ["kind", "alspmc_eliminate"], ["min", 1], ["pay", _pay],
        // Native phonePush injects raw JSON into ExecJS. ASCII here also keeps
        // the original English phone safe; our own app uses escaped Russian.
        ["title", "PMC: eliminate one target"], ["brief", "Eliminate the marked hostile. Starting crew members only."],
        ["pos", _pos], ["alspmcQuestId", _qid], ["alspmcFounder", _uid]
    ];
    private _oldOffers = +(_crew getOrDefault ["offers", []]);
    _crew set ["offers", _oldOffers + [_offer]];
    _ok = [_unit, _offer get "id"] call ALS_fnc_coopAccept;
    if (!_ok) then {
        _crew set ["offers", _oldOffers];
        ALSPMC_questRecords deleteAt _qid;
        if (_createdCrew) then {ALS_crews deleteAt (_crew get "id")};
        call ALS_fnc_crewPublish;
    } else {
        private _job = ALS_coopJobs get (_offer get "id");
        private _members = _team apply {[_x] call ALS_fnc_findPlayer};
        ["tick", _job, _members] call ALSPMC_fnc_questScenario;
        call ALSPMC_fnc_questSave;
        call ALS_fnc_dbSave;
    };
};
_cache pushBack [_token, _op, _arg, _ok];
if (count _cache > 32) then {_cache deleteAt 0};
ALSPMC_questRequests set [_uid, _cache];
_ok
