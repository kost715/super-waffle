params ["_unit"];
private _uid = [_unit] call ALS_fnc_uid;
private _ready = missionNamespace getVariable ["ALSPMC_questsReady", false];
private _crew = [_uid] call ALS_fnc_crewOf;
private _nativeJob = (missionNamespace getVariable ["ALS_coopJobs", createHashMap]) getOrDefault [_crew getOrDefault ["job", -1], createHashMap];
private _records = missionNamespace getVariable ["ALSPMC_questRecords", createHashMap];
private _active = createHashMap;
private _history = [];
private _ownActive = false;
private _ids = keys _records;
_ids sort false;
{
    private _row = _records get _x;
    _row params ["_founder", "_status", "_pay", "_pos", "_team", "_start", "_end", "_reason"];
    if (_founder == _uid && {_status == "active"}) then {_ownActive = true};
    if (_founder == _uid || {_uid in _team}) then {
        private _view = createHashMapFromArray [["id", "q" + str _x], ["status", _status], ["pay", _pay],
            ["grid", mapGridPosition _pos], ["teamSize", count _team], ["reason", _reason], ["date", _end]];
        if (_status == "active") then {
            _view set ["pos", _pos];
            private _sameJob = (_nativeJob getOrDefault ["alspmcQuestId", -1]) == _x;
            _view set ["canCancel", _sameJob && {(_crew get "leader") == _uid} && {(_nativeJob getOrDefault ["alspmcResult", ""]) == ""}];
            _view set ["canMap", _sameJob];
            _view set ["left", if (_sameJob) then {ceil (((_nativeJob get "since") + (_nativeJob get "alspmcTimeout") - time) max 0)} else {0}];
            _active = _view;
        } else {if (count _history < 10) then {_history pushBack _view}};
    };
} forEach _ids;
private _licensed = "alspmc_pmc" in (["lic_" + _uid, []] call ALS_fnc_dbGet);
private _base = (keys ALSPMC_bases) findIf {
    ((ALSPMC_bases get _x) select 0) == _uid && {[_uid, ALS_owned getOrDefault [_x, ""]] call ALS_fnc_canUse}
};
private _reason = switch (true) do {
    case (!_ready): {"unavailable"};
    case (_ownActive || {count _active > 0}): {"active"};
    case (!_licensed): {"license"};
    case (_base < 0): {"base"};
    case (count _crew > 0 && {(_crew get "leader") != _uid}): {"leader"};
    case (count _crew > 0 && {(_crew get "job") != -1}): {"busy"};
    case (count (_crew getOrDefault ["members", []]) > 4): {"size"};
    default {""};
};
createHashMapFromArray [["ready", _ready], ["canStart", _reason == ""], ["reason", _reason],
    ["pay", (round getNumber (configFile >> "ALSPMC_Settings" >> "questPay")) max 0 min 1000000],
    ["minDistance", (getNumber (configFile >> "ALSPMC_Settings" >> "questMinDistance")) max 300],
    ["maxDistance", (getNumber (configFile >> "ALSPMC_Settings" >> "questMaxDistance")) max (((getNumber (configFile >> "ALSPMC_Settings" >> "questMinDistance")) max 300) + 100)],
    ["timeout", (getNumber (configFile >> "ALSPMC_Settings" >> "questTimeout")) max 60],
    ["active", _active], ["history", _history]]
