# Development

Use the existing checkout. Do not create a worktree unless the user requests one.
No services, credentials or extra packages are required for the Python build and
archive/contract tests. Python 3.10+ and Node.js 18+ are sufficient for those checks.

```sh
python3 tools/build.py
python3 -m unittest discover -s tests -v
```

SQF syntax and executable transaction checks use SQF-VM from
https://github.com/SQFvm/runtime/releases/tag/v2026.04.03-ed9f5f5 .
Linux asset: `sqfvm_linux_x64_gcc.zip`.
Verify SHA-256 before unpacking or running:
`bb4e3bb415305d2ef2c4cdb75e98f442baea3a4575887c6570a11435a780615b`.
Do not disable download/TLS verification. The binary is a development dependency,
not included in the mod and not needed to run it in Arma 3.

In this cloud snapshot it is installed at
`/workspace/tools/sqfvm/sqfvm_linux_x64_gcc/sqfvm`.

```sh
python3 tools/check_sqf.py --vm /workspace/tools/sqfvm/sqfvm_linux_x64_gcc/sqfvm \
  --lifesim /workspace/scratch/lifesim/unpacked
```

The native function source is loaded from the separately supplied LifeSim tree.
The SQF-VM fixture supplies compatibility shims for unsupported operators,
including hashmap `getOrDefault`, `toArray`, `values` and iteration, and mocks
engine/network/UI commands and world-side effects. It adapts compiled opcodes;
it does not remove application checks. Monetary and ownership assertions execute the addon's SQF plus
native money, licence, business and claim functions. These checks demonstrate
script behavior under fixtures; they do not demonstrate Arma networking, ACE
interaction, rendering, real profile saves or live-map correctness.

Required game dependencies: Arma 3 supporting the LifeSim build, LifeSim 0.10.1,
CBA_A3 and the ACE components required by LifeSim. The optional RU beta 3 variant
registers the same `als_main` patch; use one LifeSim variant at a time.

No mod signing key is bundled. Dedicated servers that require signatures must
sign the reviewed PBO with their own approved mod key before installation.

Optional browser regression checks use Playwright and system Chromium against
the actual, separately supplied original and RU beta 3 `ui/licenses.html`:

```sh
python3 tools/check_license_ui.py --original /path/to/original/ui/licenses.html \
  --russian /path/to/ru-beta3/ui/licenses.html
python3 tools/check_phone_ui.py --original /path/to/original/ui/phone.html \
  --russian /path/to/ru-beta3/ui/phone.html
python3 tools/check_desktop_ui.py
```

These check that the legacy licence screen hides only the PMC entry, while its
native purchase protocol is unchanged. Phone scenarios cover app registration,
licence/base prerequisites and confirmation, Cyrillic naming, draft/focus retention,
local and server commands, permissions, layout, and all original phone apps.
The phone test executes the same ASCII-escaped script shipped inside the PBO.

Desktop scenarios load the addon's own HTML, inject that same controller, and
check navigation, shared commands, Cyrillic input, confirmations, notifications,
keyboard/window closing and layout. Server fixtures cover migration from a saved
phone-era base, spawning/idempotence, physical and native ownership authorization,
shared phone/desktop state, partial reconstruction, sale and ownership cleanup.
Additional adapters supply VM object creation, flat-world placement, model bounds
and physics/transform calls. The four test-only CfgVehicles declarations contain
no game models. The actual floor/wall/roof ray tests in terminalFindSpot, asset
appearance, in-game actions, camera and CEF integration need Arma 3 validation.
