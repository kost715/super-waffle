// Fixture class names only. These are not model assets or production config.
class CfgVehicles {
    class Land_TableDesk_F {};
    class Land_PCSet_01_screen_F {};
    class Land_PCSet_01_case_F {};
    class Land_PCSet_01_keyboard_F {};
};
