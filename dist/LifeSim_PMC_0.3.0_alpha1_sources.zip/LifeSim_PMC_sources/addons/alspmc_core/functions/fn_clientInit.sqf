if (missionNamespace getVariable ["ALSPMC_clientStarted", false]) exitWith {};
ALSPMC_clientStarted = true;
ALSPMC_phoneCode = loadFile "\alspmc_core\ui\phone.js";
ALSPMC_licenseCode = loadFile "\alspmc_core\ui\licensePhoneOnly.js";
"ALSPMC_basesPublic" addPublicVariableEventHandler {call ALSPMC_fnc_applyValues};
call ALSPMC_fnc_applyValues;
[{call ALSPMC_fnc_clientTick}, 0.25] call CBA_fnc_addPerFrameHandler;
