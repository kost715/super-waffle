class CfgPatches {
    class alspmc_core {
        name = "LifeSim PMC - Headquarters";
        author = "LifeSim PMC project";
        requiredVersion = 2.20;
        requiredAddons[] = {"als_main", "cba_main"};
        units[] = {};
        weapons[] = {};
    };
};

// Native licInit and licPush enumerate this class on every machine.
class ALS_Licenses {
    class alspmc_pmc {
        name = "PMC establishment license";
        desc = "Establish a PMC and buy a vacant warehouse as its base.";
        price = 1;
        rank = 0;
        covers[] = {};
    };
};

class ALSPMC_Settings {
    basePrice = 1;
    allowedTypes[] = {"Industrial"};
    terminalDesk = "Land_TableDesk_F";
    terminalScreen = "Land_PCSet_01_screen_F";
    terminalCase = "Land_PCSet_01_case_F";
    terminalKeyboard = "Land_PCSet_01_keyboard_F";
};

class CfgFunctions {
    class ALSPMC {
        tag = "ALSPMC";
        class Core {
            file = "\alspmc_core\functions";
            class postInit {postInit = 1;};
            class serverInit {};
            class clientInit {};
            class clientTick {};
            class buyBase {};
            class requestAllowed {};
            class message {};
            class save {};
            class reconcile {};
            class applyValues {};
            class sellHouse {};
            class phoneMsg {};
            class phoneDo {};
            class phoneSync {};
            class normalizeName {};
            class setName {};
            class markBase {};
            class terminalInit {};
            class terminalSync {};
            class terminalEnsure {};
            class terminalRemove {};
            class terminalFindSpot {};
            class terminalCanUse {};
            class desktopOpen {};
            class desktopTick {};
            class desktopDo {};
            class desktopView {};
        };
    };
};

// Add only our RPCs. Do not change the mission's global remote-exec mode.
class CfgRemoteExec {
    class Functions {
        class ALSPMC_fnc_buyBase {allowedTargets = 2; jip = 0;};
        class ALSPMC_fnc_message {allowedTargets = 1; jip = 0;};
        class ALSPMC_fnc_phoneDo {allowedTargets = 2; jip = 0;};
        class ALSPMC_fnc_desktopDo {allowedTargets = 2; jip = 0;};
    };
};
