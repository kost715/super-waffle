// SQF-VM 2026.04 lacks several Arma operators. Adapt compiled opcodes, not
// application branches, and record the compatibility surface explicitly.
TEST_isServer = true;
TEST_hasInterface = false;
TEST_isRemoteExecuted = false;
TEST_remoteOwner = 2;
TEST_messages = [];
TEST_published = [];
TEST_profilesSaved = 0;

TEST_fnc_getDefault = {
    params ["_compatMap", "_compatArgs"];
    if !((_compatArgs select 0) in _compatMap) exitWith {_compatArgs select 1};
    _compatMap get (_compatArgs select 0)
};
TEST_fnc_setVariable = {
    params ["_compatTarget", "_compatArgs"];
    _compatTarget setVariable (_compatArgs select [0,2]);
};
TEST_fnc_toPairs = {
    params ["_compatMap", "_compatOption"];
    (keys _compatMap) apply {[_x, _compatMap get _x]}
};
TEST_fnc_values = {private _compatMap = _this; (keys _compatMap) apply {_compatMap get _x}};
TEST_fnc_forEach = {
    params ["_compatCode", "_compatCollection"];
    if (_compatCollection isEqualType []) exitWith {_compatCode forEach _compatCollection};
    {
        private _compatKey = _x;
        private _compatValue = _compatCollection get _compatKey;
        private _x = _compatKey;
        private _y = _compatValue;
        call _compatCode;
    } forEach (keys _compatCollection);
};
TEST_fnc_remote = {TEST_messages pushBack _this; 0};
TEST_fnc_publish = {TEST_published pushBack _this};
TEST_fnc_isPlayer = {_this getVariable ["TEST_player", false]};
TEST_fnc_owner = {_this getVariable ["TEST_owner", 2]};
// Text rendering is outside the transaction fixture. Keep the localization
// key visible in recorded messages; the browser/XML tests check actual text.
TEST_fnc_localize = {_this};

TEST_fnc_compatCode = {
    private _compatOut = [];
    {
        private _compatLine = _x;
        if ((_compatLine select [0, 6]) == "PUSH {") then {
            private _compatNested = call compile (_compatLine select [5]);
            _compatLine = "PUSH " + str (_compatNested call TEST_fnc_compatCode);
        };
        switch (_compatLine) do {
            case "CALLNULAR isserver": {_compatOut pushBack "GETVARIABLE TEST_isServer"};
            case "CALLNULAR hasinterface": {_compatOut pushBack "GETVARIABLE TEST_hasInterface"};
            case "CALLNULAR isremoteexecuted": {_compatOut pushBack "GETVARIABLE TEST_isRemoteExecuted"};
            case "CALLNULAR remoteexecutedowner": {_compatOut pushBack "GETVARIABLE TEST_remoteOwner"};
            case "CALLBINARY getordefault": {_compatOut append ["MAKEARRAY 2", "GETVARIABLE TEST_fnc_getDefault", "CALLBINARY call"]};
            case "CALLBINARY toarray": {_compatOut append ["MAKEARRAY 2", "GETVARIABLE TEST_fnc_toPairs", "CALLBINARY call"]};
            case "CALLBINARY setvariable": {_compatOut append ["MAKEARRAY 2", "GETVARIABLE TEST_fnc_setVariable", "CALLBINARY call"]};
            case "CALLUNARY values": {_compatOut append ["GETVARIABLE TEST_fnc_values", "CALLBINARY call"]};
            case "CALLBINARY foreach": {_compatOut append ["MAKEARRAY 2", "GETVARIABLE TEST_fnc_forEach", "CALLBINARY call"]};
            case "CALLBINARY remoteexec";
            case "CALLBINARY remoteexeccall": {_compatOut append ["MAKEARRAY 2", "GETVARIABLE TEST_fnc_remote", "CALLBINARY call"]};
            case "CALLUNARY publicvariable": {_compatOut append ["GETVARIABLE TEST_fnc_publish", "CALLBINARY call"]};
            case "CALLUNARY isplayer": {_compatOut append ["GETVARIABLE TEST_fnc_isPlayer", "CALLBINARY call"]};
            case "CALLUNARY owner": {_compatOut append ["GETVARIABLE TEST_fnc_owner", "CALLBINARY call"]};
            case "CALLUNARY localize": {_compatOut append ["GETVARIABLE TEST_fnc_localize", "CALLBINARY call"]};
            case "CALLNULAR saveprofilenamespace": {_compatOut append ["GETVARIABLE TEST_profilesSaved", "PUSH 1", "CALLBINARY +", "ASSIGNTO TEST_profilesSaved"]};
            default {_compatOut pushBack _compatLine};
        };
    } forEach (assembly__ _this);
    // VM's assembler expects quoted identifiers although assembly__ omits them.
    _compatOut = _compatOut apply {
        private _space = _x find " ";
        private _op = if (_space < 0) then {_x} else {_x select [0, _space]};
        if (_op in ["GETVARIABLE", "ASSIGNTO", "ASSIGNTOLOCAL"]) then {
            _op + " " + str (_x select [_space + 1])
        } else {_x}
    };
    fromAssembly__ _compatOut
};
TEST_fnc_load = {(compile preprocessFileLineNumbers _this) call TEST_fnc_compatCode};
