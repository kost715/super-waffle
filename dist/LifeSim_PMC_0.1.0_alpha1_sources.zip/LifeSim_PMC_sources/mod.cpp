name = "LifeSim PMC - Foundation 0.1.0 alpha 1";
author = "LifeSim PMC project";
description = "Optional PMC foundation for Arma LifeSim 0.10.1: licence and base purchase.";
tooltip = "LifeSim PMC";
overview = "Optional addon: a PMC establishment licence and a warehouse base, both 1 euro for testing. Requires Arma LifeSim, CBA and ACE.";
