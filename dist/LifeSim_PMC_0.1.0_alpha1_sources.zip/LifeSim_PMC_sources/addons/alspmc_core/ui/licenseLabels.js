/* Display labels only. Keep license IDs, prices and purchase messages native. */
(() => {
  "use strict";
  const lic = window.lic;
  if (!lic || lic.ALSPMC_labelsInstalled) return;
  const nativeSet = lic.set;
  const name = "\u041b\u0438\u0446\u0435\u043d\u0437\u0438\u044f \u043d\u0430 \u0441\u043e\u0437\u0434\u0430\u043d\u0438\u0435 \u0427\u0412\u041a";
  const desc = "\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u043a\u0443\u043f\u0438\u0442\u044c \u0441\u0432\u043e\u0431\u043e\u0434\u043d\u044b\u0439 \u0441\u043a\u043b\u0430\u0434 \u0438\u043b\u0438 \u0430\u043d\u0433\u0430\u0440 \u043f\u043e\u0434 \u0431\u0430\u0437\u0443 \u0427\u0412\u041a. \u0422\u0435\u0441\u0442\u043e\u0432\u0430\u044f \u0446\u0435\u043d\u0430 \u043b\u0438\u0446\u0435\u043d\u0437\u0438\u0438: 1 \u20ac.";
  lic.set = function (state) {
    const list = state.list.map(row => {
      if (row[0] !== "alspmc_pmc") return row;
      const display = row.slice();
      display[1] = name;
      display[3] = desc;
      return display;
    });
    return nativeSet.call(this, {...state, list});
  };
  lic.ALSPMC_labelsInstalled = true;
})();
