if (!isServer || {missionNamespace getVariable ["ALSPMC_serverStarted", false]}) exitWith {};
ALSPMC_serverStarted = true;
ALSPMC_ready = false;
publicVariable "ALSPMC_ready";
ALSPMC_bases = createHashMap;
[["alspmc_bases_v1"]] call ALS_fnc_dbLoading;
private _saved = ["alspmc_bases_v1", []] call ALS_fnc_dbGet;
private _valid = _saved isEqualType [];
if (_valid) then {
    {
        private _good = _x isEqualType [] && {count _x == 2};
        if (_good) then {
            _x params ["_key", "_record"];
            _good = _key isEqualType "" && {_record isEqualType []} && {count _record == 3};
            if (_good) then {
                _record params ["_founder", "_marketValue", "_paid"];
                _good = _founder isEqualType "" && {_founder != ""} && {
                    _marketValue isEqualType 0 && {_marketValue >= 0}
                } && {_paid isEqualType 0 && {_paid > 0}};
            };
            if (_good) then {ALSPMC_bases set [_key, +_record]};
        };
        if (!_good) then {_valid = false};
    } forEach _saved;
};
if (!_valid) exitWith {
    ALSPMC_bases = createHashMap;
    ["ALSPMC: base data invalid; original save preserved, purchases disabled"] call ALS_fnc_log;
};
[["alspmc_bases_v1"], true] call ALS_fnc_dbLoading;

// Compose with the original function; ordinary property sales stay native.
ALSPMC_nativeHouseSell = ALS_fnc_houseSell;
ALS_fnc_houseSell = {_this call ALSPMC_fnc_sellHouse};
call ALSPMC_fnc_reconcile;
call ALSPMC_fnc_save;
ALSPMC_ready = true;
publicVariable "ALSPMC_ready";
[{call ALSPMC_fnc_reconcile}, 2] call CBA_fnc_addPerFrameHandler;
