if (!hasInterface) exitWith {};
if (isRemoteExecuted && {remoteExecutedOwner != 2}) exitWith {};
params [["_id", "", [""]], ["_args", [], [[]]]];
if ((_id select [0, 11]) != "STR_ALSPMC_") exitWith {};
private _text = format ([localize _id] + _args);
systemChat _text;
hint _text;
