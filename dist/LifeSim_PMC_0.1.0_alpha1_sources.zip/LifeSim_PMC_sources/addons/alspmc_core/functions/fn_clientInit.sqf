if (missionNamespace getVariable ["ALSPMC_clientStarted", false]) exitWith {};
ALSPMC_clientStarted = true;
[player] call ALSPMC_fnc_addActions;
["unit", {params ["_unit"]; [_unit] call ALSPMC_fnc_addActions}] call CBA_fnc_addPlayerEventHandler;
"ALSPMC_basesPublic" addPublicVariableEventHandler {call ALSPMC_fnc_applyValues};
call ALSPMC_fnc_applyValues;
[{call ALSPMC_fnc_clientTick}, 0.25] call CBA_fnc_addPerFrameHandler;
