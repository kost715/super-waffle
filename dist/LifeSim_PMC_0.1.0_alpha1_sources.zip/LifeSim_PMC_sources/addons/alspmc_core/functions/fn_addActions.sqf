params ["_unit"];
if (isNull _unit || {_unit getVariable ["ALSPMC_actionsAdded", false]}) exitWith {};
_unit setVariable ["ALSPMC_actionsAdded", true];
private _price = (round getNumber (configFile >> "ALSPMC_Settings" >> "basePrice")) max 1;
_unit addAction [
    format ["<t color='#2fd4a0'>%1</t>", format [localize "STR_ALSPMC_buy_action", _price]],
    {
        private _key = missionNamespace getVariable ["ALS_lookHouse", ""];
        [_key] spawn {
            params ["_key"];
            private _price = (round getNumber (configFile >> "ALSPMC_Settings" >> "basePrice")) max 1;
            private _yes = [format [localize "STR_ALSPMC_confirm", _price],
                localize "STR_ALSPMC_title", true, true] call BIS_fnc_guiMessage;
            if (_yes) then {[player, _key] remoteExecCall ["ALSPMC_fnc_buyBase", 2]};
        };
    }, nil, 1.65, false, true, "", "call ALSPMC_fnc_canBuyHere", 30
];
_unit addAction [localize "STR_ALSPMC_status_action", {call ALSPMC_fnc_showStatus},
    nil, 0.3, false, true, "", "alive player && {isNull objectParent player}"];
