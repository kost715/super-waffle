private _license = "alspmc_pmc" in (player getVariable ["ALS_lic", []]);
private _uid = [player] call ALS_fnc_uid;
private _bases = (missionNamespace getVariable ["ALSPMC_basesPublic", []]) select {
    ((_x select 1) select 0) == _uid || {
        private _k = _x select 0;
        ((missionNamespace getVariable ["ALS_ownedPublic", []]) findIf {
            (_x select 0) == _k && {[_x select 2] call ALS_fnc_mine}
        }) >= 0
    }
};
private _where = localize "STR_ALSPMC_no_base";
if (_bases isNotEqualTo []) then {
    private _h = ALS_houses getOrDefault [(_bases select 0) select 0, []];
    if (_h isNotEqualTo []) then {_where = format ["%1 (%2)", _h select 4, mapGridPosition (_h select 0)]};
};
hint format [localize "STR_ALSPMC_status", [localize "STR_ALSPMC_not_bought", localize "STR_ALSPMC_bought_label"] select _license, _where];
if (_bases isNotEqualTo []) then {
    private _h = ALS_houses get ((_bases select 0) select 0);
    private _m = "ALSPMC_myBase";
    if (markerShape _m == "") then {createMarkerLocal [_m, _h select 0]};
    _m setMarkerPosLocal (_h select 0);
    _m setMarkerTypeLocal "mil_flag";
    _m setMarkerColorLocal "ColorGUER";
    _m setMarkerTextLocal (localize "STR_ALSPMC_base_marker");
} else {deleteMarkerLocal "ALSPMC_myBase"};
