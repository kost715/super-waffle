disableSerialization;
// Install the display-only labels after the native license browser is ready.
// ASCII JS with Unicode escapes avoids the web bridge's UTF-8 byte problem.
private _disp = uiNamespace getVariable ["ALS_licDisp", displayNull];
if (!isNull _disp && {!isNil "ALS_lic"} && {ALS_lic getOrDefault ["ready", false]} && {
    !(_disp getVariable ["ALSPMC_labelsInstalled", false])
}) then {
    (ALS_lic get "web") ctrlWebBrowserAction ["ExecJS", loadFile "\alspmc_core\ui\licenseLabels.js"];
    _disp setVariable ["ALSPMC_labelsInstalled", true];
    ALS_lic set ["last", ""];
};
