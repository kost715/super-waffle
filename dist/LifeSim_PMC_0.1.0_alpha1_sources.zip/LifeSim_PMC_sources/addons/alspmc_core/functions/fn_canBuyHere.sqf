if (isNull player || {!alive player} || {!isNull objectParent player}) exitWith {false};
private _key = missionNamespace getVariable ["ALS_lookHouse", ""];
private _h = ALS_houses getOrDefault [_key, []];
if (count _h < 8) exitWith {false};
if !((_h select 6) in getArray (configFile >> "ALSPMC_Settings" >> "allowedTypes")) exitWith {false};
if ((_h select 7) == "Wrecked") exitWith {false};
if (_key in (missionNamespace getVariable ["ALS_reserved", []])) exitWith {false};
((missionNamespace getVariable ["ALS_ownedPublic", []]) findIf {(_x select 0) == _key}) < 0
