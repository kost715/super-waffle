params ["_unit", "_entry"];
_entry params ["_type", "_category", "_mode"];
private _plan = createHashMap;
private _site = [];
private _destination = [];
if (_mode in ["bandits", "enemyPatrol", "sector", "mines"]) then {
    private _pos = [_unit] call ALSPMC_fnc_questSite;
    if (_pos isNotEqualTo []) then {_site = [_pos, "field", objNull, [], ""]};
} else {
    private _kind = if (_category == "private") then {"commercial"} else {if (_mode == "guard") then {"government"} else {"army"}};
    if (_mode == "base") then {_kind = "enemyBase"};
    private _sites = [_kind] call ALSPMC_fnc_contractSites;
    // Avoid stacking active contracts on the same source building/base.
    _sites = _sites select {
        private _pos = _x select 0;
        private _ownerOK = true;
        if (_kind in ["army", "enemyBase"]) then {
            _ownerOK = (((missionNamespace getVariable ["ALS_war", createHashMap]) getOrDefault ["own", createHashMap]) getOrDefault [_x select 1, "Military"]) == (["Military", "Opfor"] select (_kind == "enemyBase"));
        };
        _ownerOK && {((values ALS_coopJobs) findIf {_x getOrDefault ["alspmcContract", false] && {(_x get "alspmcSite") distance2D _pos < 250}}) < 0}
    };
    if (_sites isNotEqualTo []) then {
        private _offset = floor random count _sites;
        for "_i" from 0 to ((count _sites - 1) min 30) do {
            private _candidate = +(_sites select ((_offset + _i) mod count _sites));
            if (_mode == "guard" && {_kind == "commercial"}) then {
                private _object = [_candidate select 1] call ALS_fnc_houseObj;
                private _floor = if (isNull _object) then {[]} else {[_object] call ALS_fnc_houseFloor};
                if (_floor isNotEqualTo []) then {_candidate set [2, _object]; _candidate set [3, _floor select 0]};
            };
            if (_mode != "guard" || {(_candidate select 3) isNotEqualTo []}) exitWith {_site = _candidate};
        };
    };
    if (_site isNotEqualTo [] && {_mode in ["convoy", "vip"]}) then {
        private _destinations = ([_kind] call ALSPMC_fnc_contractSites) select {
            (_x select 1) != (_site select 1) && {(_x select 0) distance2D (_site select 0) >= 1000}
        };
        // Army convoys may finish at another native government facility.
        if (_category == "government") then {
            _destinations append ((["government"] call ALSPMC_fnc_contractSites) select {(_x select 0) distance2D (_site select 0) >= 1000});
        };
        if (_destinations isNotEqualTo []) then {_destination = selectRandom _destinations};
    };
};
if (_site isEqualTo [] || {_mode in ["convoy", "vip"] && {_destination isEqualTo []}}) exitWith {_plan};
_plan set ["site", _site select 0]; _plan set ["source", _site select 1];
_plan set ["building", _site select 2]; _plan set ["indoor", _site select 3];
if (_destination isNotEqualTo []) then {_plan set ["destination", _destination select 0]};
if (_mode == "convoy") then {
    private _spots = [_site select 0, _destination select 0, "C_Truck_02_transport_F", 1, 250] call ALS_fnc_warRoadSpot;
    private _endRoad = [_destination select 0, 250] call ALS_fnc_roadNear;
    if (_spots isEqualTo [] || {isNull _endRoad}) then {_plan = createHashMap} else {
        _plan set ["truckPos", (_spots select 0) select 0];
        _plan set ["truckDir", _spots select 1];
        _plan set ["destination", getPosATL _endRoad];
    };
};
_plan
