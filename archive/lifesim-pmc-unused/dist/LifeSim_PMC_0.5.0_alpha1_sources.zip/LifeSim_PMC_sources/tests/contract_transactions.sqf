// New contracts: production planning is separately probed below; only world
// placement/AI/network calls are replaced. Mission logic and wallets are real.
private _findBefore = ALS_fnc_findPlayer;
private _planBefore = ALSPMC_fnc_contractPlan;
private _siteBefore = ALSPMC_fnc_questSite;
private _sitesBefore = ALSPMC_fnc_contractSites;
ALS_fnc_findPlayer = {
    private _uid = _this select 0;
    (TEST_players select {([_x] call ALS_fnc_uid) == _uid}) param [0, objNull]
};
TEST_building = "TestBuilding_F" createVehicle [1000,100,0];
TEST_building2 = "TestBuilding_F" createVehicle [3000,100,0];
TEST_road = "TestVan_F" createVehicle [3000,100,0];
TEST_fnc_sitesFixture = {
    switch (_this select 0) do {
        case "army": {[[[1000,100,0],"army",objNull,[],"Military"]]};
        case "enemyBase": {[[[1000,100,0],"b_enemy",objNull,[],"Opfor"]]};
        case "government": {[[[3000,100,0],"gov",TEST_building2,[3000,100,1],""]]};
        case "commercial": {[[[1000,100,0],"shop1",objNull,[],""],[[3000,100,0],"shop2",objNull,[],""]]};
        default {[]};
    }
};
// Probe the real route/site planner using known native registry/geometry
// boundaries. No planning branch is removed or replaced in these probes.
call TEST_fnc_reset;
ALSPMC_fnc_contractSites = TEST_fnc_sitesFixture;
ALS_fnc_warRoadSpot = {[[(_this select 0)],90,[90]]};
ALS_fnc_roadNear = {TEST_road setPos (_this select 0); TEST_road};
ALS_fnc_houseObj = {if ((_this select 0) == "shop1") then {TEST_building} else {TEST_building2}};
ALS_fnc_houseFloor = {(getPos (_this select 0)) vectorAdd [0,0,1] call {[_this]}};
ALSPMC_fnc_questSite = {[1000,100,0]};
(ALS_war get "own") set ["army","Military"]; (ALS_war get "own") set ["b_enemy","Opfor"];
{
    private _plan = [player,_x] call _planBefore;
    [count _plan > 0 && {count (_plan get "site") == 3}, "production planner finds a native site/route: " + (_x select 0)] call TEST_fnc_assert;
    if ((_x select 2) == "guard") then {[count (_plan get "indoor") == 3, "guard planner requires an actual indoor floor position"] call TEST_fnc_assert};
    if ((_x select 2) == "convoy") then {[count (_plan get "truckPos") == 3 && {count (_plan get "destination") == 3}, "convoy planner resolves both endpoints to native roads"] call TEST_fnc_assert};
} forEach (call ALSPMC_fnc_contractCatalog);
ALSPMC_fnc_contractSites = _sitesBefore;
ALSPMC_contractSitesCache = createHashMap;
ALS_war = createHashMapFromArray [["on",true],["bases",[["army",[1000,100,0],"outpost",8,"Ours"],["enemy",[3000,100,0],"outpost",8,"Theirs"]]],
    ["own",createHashMapFromArray [["army","Military"],["enemy","Opfor"]]]];
[count (["army"] call ALSPMC_fnc_contractSites) == 1 && {count (["enemyBase"] call ALSPMC_fnc_contractSites) == 1}, "native site provider separates friendly outposts and actual opposing bases"] call TEST_fnc_assert;
ALS_war set ["on",false]; ALSPMC_contractSitesCache = createHashMap;
[count (["enemyBase"] call ALSPMC_fnc_contractSites) == 0, "inactive native war does not invent an opposing military base"] call TEST_fnc_assert;
ALSPMC_fnc_contractSites = TEST_fnc_sitesFixture;
ALSPMC_fnc_contractPlan = {
    createHashMapFromArray [["site",[1000,100,0]],["source","b_enemy"],["building",TEST_building],
        ["indoor",[1000,100,1]],["destination",[3000,100,0]],["truckPos",[1000,100,0]],["truckDir",90]]
};
TEST_fnc_contractReset = {
    call TEST_fnc_reset;
    TEST_actor = player;
    player setPos [100,100,0];
    ["p1","alspmc_pmc"] call ALS_fnc_licGrant;
    [player,"h_100_100"] call ALSPMC_fnc_buyBase;
    ["money_p1",[0,0]] call ALS_fnc_dbSet;
    call ALSPMC_fnc_questInit;
};
TEST_fnc_emitContractState = {
    [TEST_actor,0,true] call ALSPMC_fnc_phoneSync;
    diag_log ("TEST_CONTRACT_STATE: " + ((TEST_actor getVariable "ALSPMC_phoneState") call TEST_fnc_toJSON));
};
TEST_fnc_contractStart = {
    params ["_type", "_token"];
    [[TEST_actor,"questStart",_type,_token] call ALSPMC_fnc_phoneDo, "start real contract: " + _type] call TEST_fnc_assert;
    private _c = ["p1"] call ALS_fnc_crewOf;
    ALS_coopJobs get (_c get "job")
};
TEST_fnc_contractReady = {
    params ["_job", "_token"];
    TEST_actor setPos [1000,100,0];
    if (missionNamespace getVariable ["TEST_captureContractUI", false]) then {call TEST_fnc_emitContractState};
    [[TEST_actor,"questReady","q" + str (_job get "alspmcQuestId"),_token] call ALSPMC_fnc_phoneDo,
        "readiness at the real contract site: " + (_job get "alspmcType")] call TEST_fnc_assert;
    _job set ["alspmcAttackPlanned", false];
    if (missionNamespace getVariable ["TEST_captureContractUI", false]) then {
        call TEST_fnc_emitContractState;
        TEST_contractNativeMirror = +(TEST_actor getVariable "ALS_coopJob");
    };
};
TEST_fnc_contractKill = {
    params ["_job", ["_killer",player]];
    {private _victim = _x select 0; if (!isNull _victim) then {_victim setDamage 1; [_victim,_killer,_killer] call ALSPMC_fnc_questKilled}} forEach (_job get "alspmcEnemies");
};

call TEST_fnc_contractReset;
private _catalog = call ALSPMC_fnc_contractCatalog;
[count _catalog == 10 && {count (_catalog select {(_x select 1) == "government"}) == 7}, "catalog contains seven government and three private contracts"] call TEST_fnc_assert;
[(["p1"] call ALSPMC_fnc_contractProfile) get "level" == 1, "existing founder starts with rating level one"] call TEST_fnc_assert;
call TEST_fnc_emitContractState;
[!([player,"questStart","gov_base",2000] call ALSPMC_fnc_phoneDo) && {!([player,"questStart","gov_patrol",2001] call ALSPMC_fnc_phoneDo)}, "base and patrol assaults are locked below levels four and three"] call TEST_fnc_assert;
ALSPMC_ratingXP set ["p1",300];
[(["p1"] call ALSPMC_fnc_contractProfile) get "level" == 3, "threshold 300 unlocks rating level three"] call TEST_fnc_assert;
[!([player,"questStart","gov_base",2002] call ALSPMC_fnc_phoneDo), "base assault remains locked at level three"] call TEST_fnc_assert;
ALSPMC_ratingXP set ["p1",600];
[(["p1"] call ALSPMC_fnc_contractProfile) get "level" == 4, "threshold 600 unlocks rating level four"] call TEST_fnc_assert;

// Every requested scenario completes via native acceptance/tick and our scoped
// settlement. No new scenario may go through native per-member/company pay.
private _offset = 0;
{
    private _entry = _x;
    private _type = _entry select 0;
    private _mode = _entry select 2;
    TEST_captureContractUI = _type == "gov_guard";
    call TEST_fnc_contractReset;
    ALSPMC_ratingXP set ["p1",1000];
    if (_type == "gov_guard") then {call TEST_fnc_emitContractState};
    private _job = [_type,2100 + _offset] call TEST_fnc_contractStart;
    _offset = _offset + 2;
    private _qid = _job get "alspmcQuestId";
    private _reward = (_entry select 4) * 4;
    if (_type == "gov_guard") then {call TEST_fnc_emitContractState};
    [(_job get "alspmcProfile") get "level" == 5 && {(_job get "pay") == _reward}, "accepted rating and budget are frozen: " + _type] call TEST_fnc_assert;
    if (_mode == "bandits") then {
        [count (_job get "alspmcEnemies") >= 17 && {count (_job get "alspmcEnemies") <= 27}, "level five creates 15-25 infantry plus the pickup crew"] call TEST_fnc_assert;
        [((_job get "alspmcObjects") findIf {(_x getVariable ["TEST_class",""]) == "I_G_Offroad_01_armed_F"}) >= 0, "highest bandit tier always has one machine-gun pickup"] call TEST_fnc_assert;
        [((_job get "alspmcEnemies") findIf {!((((_x select 0) getVariable ["ALSPMC_loadout",[]]) select 0) in ["arifle_MX_F","LMG_Mk200_F","srifle_EBR_F"])}) < 0, "high tier uses rifle/MG/DMR whitelist without launchers"] call TEST_fnc_assert;
    };
    if (_mode == "enemyPatrol") then {[count (_job get "alspmcEnemies") >= 3 && {count (_job get "alspmcEnemies") <= 10}, "enemy patrol total never exceeds ten including vehicle crew"] call TEST_fnc_assert};
    private _borrowed = objNull;
    if (_mode == "base") then {
        _borrowed = "O_G_Soldier_F" createVehicle [1000,100,0];
        _borrowed setVariable ["ALS_army","Opfor"];
        TEST_nearForces = [_borrowed];
        (ALS_war get "own") set ["b_enemy","Opfor"];
        TEST_actor setPos [1000,100,0];
        call ALS_fnc_coopTick;
    };
    if (_mode in ["guard","convoy","vip","sector"]) then {
        [(count (_job get "alspmcObjects")) == 0 && {(_job get "state") == "rendezvous"}, "assets wait for readiness: " + _type] call TEST_fnc_assert;
        [!([player,"questReady","q" + str _qid,2500 + _offset] call ALSPMC_fnc_phoneDo), "readiness far from site is rejected: " + _type] call TEST_fnc_assert;
        [_job,2600 + _offset] call TEST_fnc_contractReady;
    };
    switch (_mode) do {
        case "bandits";
        case "enemyPatrol";
        case "base": {[_job] call TEST_fnc_contractKill};
        case "guard";
        case "sector": {
            TEST_realTime = (_job get "alspmcDutyAt") + 599;
            call ALS_fnc_coopTick;
            [_qid in ALSPMC_questRecords && {(ALSPMC_questRecords get _qid) select 1 == "active"}, "duty does not finish at 599 real seconds: " + _type] call TEST_fnc_assert;
            TEST_realTime = (_job get "alspmcDutyAt") + 600;
        };
        case "convoy": {
            [count TEST_driveCalls == 1, "convoy calls native aiDrive once after readiness"] call TEST_fnc_assert;
            (_job get "alspmcTruck") setPos [3000,100,0];
        };
        case "vip": {
            [!isNull (_job get "alspmcProtected"), "readiness creates one VIP"] call TEST_fnc_assert;
            (_job get "alspmcProtected") setPos [3000,100,0]; TEST_actor setPos [3000,100,0];
        };
        case "mines": {
            TEST_actor setPos [1000,100,0];
            TEST_randomQueue = [0,0];
            call ALS_fnc_coopTick;
            [(_job get "state") == "active", "arriving starts the mine survey"] call TEST_fnc_assert;
            [count (_job get "alspmcMines") == 3, "armed branch creates real mine objects for the clearance task"] call TEST_fnc_assert;
            {if (_forEachIndex mod 2 == 0) then {_x setVariable ["TEST_mineActive",false]} else {deleteVehicle _x}} forEach (_job get "alspmcMines");
            TEST_realTime = (_job get "alspmcSurveyAt") + 60;
        };
    };
    call ALS_fnc_coopTick;
    [(ALSPMC_questRecords get _qid) select 1 == "done", "scenario completes: " + _type] call TEST_fnc_assert;
    [["p1"] call ALS_fnc_moneyGet isEqualTo [0,_reward], "entire budget reaches founder bank: " + _type] call TEST_fnc_assert;
    [(ALSPMC_ratingXP get "p1") == 1000 + (_entry select 5), "only success adds configured rating XP: " + _type] call TEST_fnc_assert;
    [((_job get "alspmcObjects") findIf {!isNull _x}) < 0, "only spawned scenario objects cleaned up: " + _type] call TEST_fnc_assert;
    if (_type == "gov_guard") then {call TEST_fnc_emitContractState};
    call ALS_fnc_coopTick;
    [_job,1] call ALS_fnc_coopEnd;
    [["p1"] call ALS_fnc_moneyGet isEqualTo [0,_reward], "repeat finish cannot pay twice: " + _type] call TEST_fnc_assert;
    if (!isNull _borrowed) then {deleteVehicle _borrowed};
} forEach _catalog;
TEST_captureContractUI = false;

// Founder-only payment also overrides a native company's jobsTo setting.
call TEST_fnc_contractReset;
private _p2 = "TestPlayer_F" createVehicle [110,100,0];
_p2 setVariable ["ALS_uid","p2"]; _p2 setVariable ["TEST_player",true]; _p2 setVariable ["TEST_owner",5];
TEST_players pushBack _p2;
private _crew = createHashMapFromArray [["id","c1"],["leader","p1"],["members",["p1","p2"]],["job",-1]];
ALS_crews set ["c1",_crew]; ALS_crewSeq = 1;
ALS_companies set ["co_1",createHashMapFromArray [["id","co_1"],["name","Co"],["members",["p1","p2"]],["jobsTo",true],["ledger",[]]]];
private _job = ["gov_bandits",3000] call TEST_fnc_contractStart;
[count (_job get "alspmcEnemies") >= 3 && {count (_job get "alspmcEnemies") <= 5}, "level one bandit group has three to five infantry and no vehicle crew"] call TEST_fnc_assert;
[((_job get "alspmcEnemies") findIf {!((((_x select 0) getVariable ["ALSPMC_loadout",[]]) select 0) in ["hgun_ACPC2_F","hgun_Pistol_heavy_02_F"])}) < 0, "level one force has only whitelisted semiautomatic pistols"] call TEST_fnc_assert;
[_job,_p2] call TEST_fnc_contractKill;
call ALS_fnc_coopTick;
[["p1"] call ALS_fnc_moneyGet isEqualTo [0,4000] && {(["p2"] call ALS_fnc_moneyGet) isEqualTo [0,0]} && {(["co_1"] call ALS_fnc_moneyGet) isEqualTo [0,0]}, "new contract pays founder only, regardless of killer or company jobsTo"] call TEST_fnc_assert;

call TEST_fnc_contractReset;
_job = ["gov_convoy",3100] call TEST_fnc_contractStart;
[_job,3101] call TEST_fnc_contractReady;
private _truck = _job get "alspmcTruck";
private _driver = _job get "alspmcDriver";
_driver setDamage 1;
call ALS_fnc_coopTick;
[count ALS_coopJobs == 1 && {_job get "alspmcDriverDead"}, "dead driver does not fail an intact truck"] call TEST_fnc_assert;
_truck setDamage 1;
call ALS_fnc_coopTick;
[(ALSPMC_questRecords get 1) select 7 == "truck" && {(["p1"] call ALS_fnc_moneyGet) isEqualTo [0,0]}, "destroyed truck fails without a reward"] call TEST_fnc_assert;

call TEST_fnc_contractReset;
_job = ["private_guard",3200] call TEST_fnc_contractStart;
[_job,3201] call TEST_fnc_contractReady;
(_job get "alspmcProtected") setDamage 1;
call ALS_fnc_coopTick;
[(ALSPMC_questRecords get 1) select 7 == "protected", "dead facility NPC fails the protection contract"] call TEST_fnc_assert;
call TEST_fnc_contractReset;
_job = ["private_vip",3202] call TEST_fnc_contractStart;
[_job,3203] call TEST_fnc_contractReady;
(_job get "alspmcProtected") setDamage 1;
call ALS_fnc_coopTick;
[(ALSPMC_questRecords get 1) select 7 == "protected", "dead VIP fails the escort contract"] call TEST_fnc_assert;

call TEST_fnc_contractReset;
_job = ["gov_sector",3300] call TEST_fnc_contractStart;
[_job,3301] call TEST_fnc_contractReady;
player setPos [1500,100,0];
call ALS_fnc_coopTick;
[(ALSPMC_questRecords get 1) select 7 == "sector", "leaving the patrol sector empty fails immediately"] call TEST_fnc_assert;

call TEST_fnc_contractReset;
_job = ["gov_guard",3310] call TEST_fnc_contractStart;
[_job,3311] call TEST_fnc_contractReady;
_job set ["alspmcAttackPlanned",true]; _job set ["alspmcAttackAt",TEST_realTime];
call ALS_fnc_coopTick;
[(_job get "alspmcAttackDone") && {count (_job get "alspmcEnemies") >= 3} && {count TEST_attackCalls > 0}, "scheduled guard attack creates attackers and native attack orders"] call TEST_fnc_assert;
[player,"questCancel","q1",3312] call ALSPMC_fnc_phoneDo;
call TEST_fnc_contractReset;
_job = ["private_vip",3320] call TEST_fnc_contractStart;
[_job,3321] call TEST_fnc_contractReady;
_job set ["alspmcAttackPlanned",true];
(_job get "alspmcProtected") setPos [1700,100,0]; player setPos [1700,100,0];
TEST_realTime = TEST_realTime + 31;
call ALS_fnc_coopTick;
[(_job get "alspmcAttackDone") && {count (_job get "alspmcEnemies") >= 3}, "VIP ambush waits for progress along the route and then targets the escorted person"] call TEST_fnc_assert;
[player,"questCancel","q1",3322] call ALSPMC_fnc_phoneDo;
call TEST_fnc_contractReset;
_job = ["gov_mines",3330] call TEST_fnc_contractStart;
player setPos [1000,100,0]; TEST_randomQueue = [0.99];
call ALS_fnc_coopTick;
[count (_job get "alspmcMines") == 0 && {(ALSPMC_questRecords get 1) select 1 == "active"}, "clean minefield still requires an on-site survey"] call TEST_fnc_assert;
TEST_realTime = TEST_realTime + 60; call ALS_fnc_coopTick;
[(ALSPMC_questRecords get 1) select 1 == "done", "survey completes a field where no mines were rolled"] call TEST_fnc_assert;

// Respawn is allowed until the instant that the whole roster is dead.
call TEST_fnc_contractReset;
private _p1Body = "TestPlayer_F" createVehicle [100,100,0];
_p1Body setVariable ["ALS_uid","p1"]; _p1Body setVariable ["TEST_player",true]; _p1Body setVariable ["TEST_owner",4];
TEST_actor = _p1Body; TEST_players = [_p1Body,_p2];
_crew = createHashMapFromArray [["id","c1"],["leader","p1"],["members",["p1","p2"]],["job",-1]];
ALS_crews set ["c1",_crew]; ALS_crewSeq = 1;
_job = ["gov_bandits",3400] call TEST_fnc_contractStart;
_p1Body setDamage 1; [_p1Body,objNull,objNull] call ALSPMC_fnc_questKilled;
[(_job get "alspmcResult") == "", "one casualty does not fail a group with a living participant"] call TEST_fnc_assert;
private _respawn1 = "TestPlayer_F" createVehicle [110,100,0];
_respawn1 setVariable ["ALS_uid","p1"]; _respawn1 setVariable ["TEST_player",true];
TEST_players = [_respawn1,_p2];
[count ([_job] call ALSPMC_fnc_contractTeam) == 2, "respawned participant rejoins the current contract"] call TEST_fnc_assert;
_p2 setDamage 1; [_p2,objNull,objNull] call ALSPMC_fnc_questKilled;
[(_job get "alspmcResult") == "", "second casualty is allowed while the first has respawned"] call TEST_fnc_assert;
_respawn1 setDamage 1; [_respawn1,objNull,objNull] call ALSPMC_fnc_questKilled;
[(_job get "alspmcResult") == "wiped", "simultaneous full-roster death is captured before the next tick"] call TEST_fnc_assert;
_respawn1 setDamage 0; _p2 setDamage 0;
call ALS_fnc_coopTick;
[(ALSPMC_questRecords get 1) select 7 == "wiped" && {(["p1"] call ALS_fnc_moneyGet) isEqualTo [0,0]}, "respawning after a recorded total wipe cannot undo the failure"] call TEST_fnc_assert;
{deleteVehicle _x} forEach [_p1Body,_respawn1];

// Borrowed native base objects are never part of cancellation cleanup.
call TEST_fnc_contractReset;
ALSPMC_ratingXP set ["p1",600];
private _nativeSoldier = "O_G_Soldier_F" createVehicle [1000,100,0];
_nativeSoldier setVariable ["ALS_army","Opfor"];
TEST_nearForces = [_nativeSoldier]; (ALS_war get "own") set ["b_enemy","Opfor"];
_job = ["gov_base",3500] call TEST_fnc_contractStart;
player setPos [1000,100,0]; call ALS_fnc_coopTick;
player setPos [2500,100,0]; deleteVehicle _nativeSoldier; TEST_nearForces = [];
call ALS_fnc_coopTick;
[(ALSPMC_questRecords get 1) select 1 == "active" && {(_job get "state") == "travel"}, "native garrison streaming is not counted as kills or squad defeat"] call TEST_fnc_assert;
_nativeSoldier = "O_G_Soldier_F" createVehicle [1000,100,0]; _nativeSoldier setVariable ["ALS_army","Opfor"];
TEST_nearForces = [_nativeSoldier]; player setPos [1000,100,0]; call ALS_fnc_coopTick;
[(_job get "state") == "combat" && {(["p1"] call ALS_fnc_moneyGet) isEqualTo [0,0]}, "returning resumes the observed native garrison without a free reward"] call TEST_fnc_assert;
[[player,"questCancel","q1",3501] call ALSPMC_fnc_phoneDo, "base contract can be cancelled after the garrison is observed"] call TEST_fnc_assert;
[!isNull _nativeSoldier && {alive _nativeSoldier}, "cancelling never deletes a native garrison unit"] call TEST_fnc_assert;
deleteVehicle _nativeSoldier;

// Rating/receipt persistence uses the same native DB and an optional new key.
call TEST_fnc_contractReset;
_job = ["gov_bandits",3600] call TEST_fnc_contractStart;
[_job] call TEST_fnc_contractKill; call ALS_fnc_coopTick;
private _database = +ALS_db;
call TEST_fnc_reset; ALS_db = _database;
call ALSPMC_fnc_questInit;
[(ALSPMC_ratingXP get "p1") == 100 && {(ALSPMC_contractMeta get 1) select 3 == 4000}, "reload restores owner rating and payment receipt"] call TEST_fnc_assert;
[["p1"] call ALS_fnc_moneyGet isEqualTo [0,4000], "reloading a completed contract does not repay"] call TEST_fnc_assert;
call TEST_fnc_reset;
private _bad = [1,[[1,["unknown",1,100,0]]],[]];
["alspmc_contracts_v1",_bad] call ALS_fnc_dbSet;
call ALSPMC_fnc_questInit;
[!ALSPMC_contractsReady && {ALSPMC_ready}, "bad contract metadata does not disable base management"] call TEST_fnc_assert;
["alspmc_contracts_v1",[]] call ALS_fnc_dbSet;
[["alspmc_contracts_v1",[]] call ALS_fnc_dbGet isEqualTo _bad, "native guard preserves corrupt rating metadata"] call TEST_fnc_assert;

ALS_fnc_findPlayer = _findBefore;
ALSPMC_fnc_contractPlan = _planBefore;
ALSPMC_fnc_questSite = _siteBefore;
ALSPMC_fnc_contractSites = _sitesBefore;
deleteVehicle _p2; deleteVehicle TEST_building; deleteVehicle TEST_building2; deleteVehicle TEST_road;
