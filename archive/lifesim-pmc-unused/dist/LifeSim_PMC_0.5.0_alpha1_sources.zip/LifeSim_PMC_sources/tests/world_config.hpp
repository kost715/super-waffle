// Fixture class names only. These are not model assets or production config.
class CfgVehicles {
    class Land_TableDesk_F {};
    class Land_PCSet_01_screen_F {};
    class Land_PCSet_01_case_F {};
    class Land_PCSet_01_keyboard_F {};
    class TestVan_F {displayName = "Test van";};
    class O_G_Soldier_F {};
    class C_man_1 {};
    class C_man_w_worker_F {};
    class C_Truck_02_transport_F {};
    class C_Offroad_01_F {};
    class I_G_Offroad_01_armed_F {};
    class Land_MetalCase_01_large_F {};
    class APERSMine {};
    class TestBuilding_F {};
    class TestPlayer_F {};
};
class CfgWeapons {
    class hgun_ACPC2_F {};
    class hgun_Pistol_heavy_02_F {};
    class SMG_02_F {};
    class arifle_TRG21_F {};
    class arifle_MX_F {};
    class LMG_Mk200_F {};
    class srifle_EBR_F {};
};
