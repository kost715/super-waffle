name = "LifeSim PMC - Phone 0.2.0 alpha 1";
author = "LifeSim PMC project";
description = "Optional PMC phone app for Arma LifeSim 0.10.1: licence, base and company name.";
tooltip = "LifeSim PMC";
overview = "Optional addon: a PMC establishment licence and a warehouse base, both 1 euro for testing. Requires Arma LifeSim, CBA and ACE.";
