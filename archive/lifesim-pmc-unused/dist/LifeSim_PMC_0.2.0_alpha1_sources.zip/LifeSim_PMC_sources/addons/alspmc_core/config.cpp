class CfgPatches {
    class alspmc_core {
        name = "LifeSim PMC - Phone";
        author = "LifeSim PMC project";
        requiredVersion = 2.20;
        requiredAddons[] = {"als_main", "cba_main"};
        units[] = {};
        weapons[] = {};
    };
};

// Native licInit and licPush enumerate this class on every machine.
class ALS_Licenses {
    class alspmc_pmc {
        name = "PMC establishment license";
        desc = "Establish a PMC and buy a vacant warehouse as its base.";
        price = 1;
        rank = 0;
        covers[] = {};
    };
};

class ALSPMC_Settings {
    basePrice = 1;
    allowedTypes[] = {"Industrial"};
};

class CfgFunctions {
    class ALSPMC {
        tag = "ALSPMC";
        class Core {
            file = "\alspmc_core\functions";
            class postInit {postInit = 1;};
            class serverInit {};
            class clientInit {};
            class clientTick {};
            class buyBase {};
            class requestAllowed {};
            class message {};
            class save {};
            class reconcile {};
            class applyValues {};
            class sellHouse {};
            class phoneMsg {};
            class phoneDo {};
            class phoneSync {};
            class normalizeName {};
            class setName {};
            class markBase {};
        };
    };
};

// Add only our RPCs. Do not change the mission's global remote-exec mode.
class CfgRemoteExec {
    class Functions {
        class ALSPMC_fnc_buyBase {allowedTargets = 2; jip = 0;};
        class ALSPMC_fnc_message {allowedTargets = 1; jip = 0;};
        class ALSPMC_fnc_phoneDo {allowedTargets = 2; jip = 0;};
    };
};
