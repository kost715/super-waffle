params ["_msg"];
private _op = _msg getOrDefault ["op", ""];
private _key = _msg getOrDefault ["key", ""];
if (_op in ["mark", "furnish", "view"]) exitWith {
    private _entry = (player getVariable ["ALSPMC_phoneState", createHashMap]) getOrDefault ["bases", []];
    if ((_entry findIf {(_x get "key") == _key}) < 0) exitWith {};
    switch (_op) do {
        case "mark": {[_key] call ALSPMC_fnc_markBase};
        case "view": {[_key] call ALS_fnc_propView};
        case "furnish": {
            (ALS_phone get "disp") closeDisplay 2;
            [_key] call ALS_fnc_furnOpen;
        };
    };
};
if !(_op in ["status", "license", "name", "base", "lock", "unlock", "sell"]) exitWith {};
private _arg = if (_op == "name") then {_msg getOrDefault ["name", []]} else {_key};
[player, _op, _arg, _msg getOrDefault ["token", 0]] remoteExecCall ["ALSPMC_fnc_phoneDo", 2];
