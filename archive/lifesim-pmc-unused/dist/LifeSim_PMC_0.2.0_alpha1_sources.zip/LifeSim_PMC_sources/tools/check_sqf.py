#!/usr/bin/env python3
"""Parse shipped SQF/config and execute transaction fixtures with SQF-VM."""
import argparse
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def run(vm, args):
    result = subprocess.run([str(vm), "-a", "--suppress-welcome", "--no-execute-print",
                             "--no-work-print", "--max-runtime", "30000", *args],
                            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            timeout=45)
    # SQF-VM sometimes exits 0 on a VM error. Never use status alone as proof.
    bad = result.returncode != 0 or re.search(r"\[(?:ERR|FAT)\]|TEST_FAIL|NOT IMPLEMENTED", result.stdout)
    return not bad, result.stdout


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--vm", type=Path, required=True)
    p.add_argument("--lifesim", type=Path, required=True)
    args = p.parse_args()
    config = ROOT / "addons/alspmc_core/config.cpp"
    common = ["--command-dummy-binary", "4|ctrlWebBrowserAction",
              "--command-dummy-unary", "fromJSON", "--command-dummy-unary", "toJSON"]
    report = {"syntax": [], "arma_runtime_tested": False}
    for sqf in sorted((ROOT / "addons/alspmc_core/functions").glob("*.sqf")):
        ok, output = run(args.vm, [*common, "--parse-only", "--input-config", str(config),
                                   "--input-sqf", str(sqf)])
        report["syntax"].append({"file": sqf.name, "passed": ok})
        if not ok:
            print(output)
            raise SystemExit(f"SQF syntax failure: {sqf.name}")
    # Only the new licence config is needed by native licInit in this fixture.
    # Other native functions are supplied from the user's unmodified files.
    ok, output = run(args.vm, [*common, "--virtual", f"{ROOT}|/", "--virtual", f"{args.lifesim}|/native",
                               "--input-config", str(config), "--input-sqf", str(ROOT / "tests/transactions.sqf")])
    print(output)
    match = re.search(r"TEST_COMPLETE: (\d+) assertions", output)
    report["transactions"] = {"passed": bool(ok and match), "assertions": int(match[1]) if match else 0}
    report["compatibility_shims"] = ["isServer", "hasInterface", "isRemoteExecuted", "remoteExecutedOwner",
                                      "getOrDefault", "hashmap toArray", "hashmap forEach", "hashmap values", "remoteExec",
                                      "remoteExecCall", "publicVariable", "setVariable public flag", "isPlayer", "owner", "localize", "mapGridPosition", "toArray signed char", "saveProfileNamespace"]
    reports = ROOT / "reports"
    reports.mkdir(exist_ok=True)
    (reports / "sqf-run.txt").write_text(output)
    (reports / "sqf-checks.json").write_text(json.dumps(report, indent=2) + "\n")
    if not ok or not match:
        raise SystemExit("SQF transaction checks failed or did not complete")
    print(f"Parsed {len(report['syntax'])} SQF files; {match[1]} transaction assertions passed.")


if __name__ == "__main__":
    main()
